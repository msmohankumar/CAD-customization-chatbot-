TrackDrawingChanges_ReadMe.txt

OVERVIEW
This ReadMe describes the proper usage of the CreateSnapshotData and ExecuteCompareReport tool.

ENVIRONMENT
To run CreateSnapshotData and ExecuteCompareReport you need to run from an NX UNIX subshell or from
a Command prompt from NX tools on Windows.

   UNIX:
   NX Activity menu go to Administration Utilities-> UNIX SHELL (Start unix subshell)

   WINDOWS:
   Go to NX Tools-> Command Prompt


---------------------------------------------------------------------------------
CreateSnapshotData :
---------------------------------------------------------------------------------

USAGE
The CreateSnapshotData program allows to create the snapshot data in an NX part.
Creates CGM or overlay data only if "Create Overlay Data with Snapshot Data" Customer Default 
toggle is turned on.

CreateSnapshotData <filename> -d <dirname> -subdir -f <Filelist.txt> -t -dbg -l <logfile.txt> 
                    -time <timelimit> -TC -u=<username> -p=<password> -update
   
where:

[<filename>]        : Caches the drafting key point information for the part file
                      <filename>.User may give a list of names separated by commas
					  in native mode. For Teamcenter give CLI spec of the top part 
					  of master model. CLI spec format : @DB/<MFK ID>/<rev id>
                      Use fnd0partIdentifier property on item in teamcenter to get MFK ID
                      If only Item ID is given, may get some error 
[-d]                : Processes all the part files in current work directory.
                      This option is applicable for native mode only.
[-d <dirname>]      : Processes all the part files in the directory <dirname>.
                      This option is applicable for native mode only.
[-subdir]           : Traverses subdirectories for part files.
                      This option is applicable for native mode.
[-f <Filelist.txt>] : Process all the part files in FileList.txt. Part files 
                      are separated by new line. Teamcenter parts specified 
                      by @DB/<item_id>/<rev_id>/<relation_type>/<dataset_name>.
[-t]                : To show output on the screen.
[-l <logfile.txt>]  : Outputs log file information to specified log file. If not
                      specified, createsnapshotdata_log.txt is created in 
                      temporary directory.
[-dbg]              : Logs developer debug information to the syslog.
[-TC]               : To process in Teamcenter.
[-u=<username>]     : Teamcenter username.
                      This option is applicable for Teamcenter mode only.
[-p=<password>]     : Teamcenter password.
                      This option is applicable for Teamcenter mode only.
[-time <timelimit>] : Process the part files up to the given time limit. 
                      Provide Time in minutes.
[-update]           : Updates all the views in the drawing before creating snapshot data.
   
EXAMPLES OF USAGE
   UNIX   : CreateSnapshotData -d /parts/ug -subdir -t -dbg
   WINDOWS: CreateSnapshotData -d D:\parts\ug -subdir -t -dbg
   
   The example above runs the CreateSnapshotData program on all parts in the
   D:\parts\ug directory and creates snapshot.
   
        
PROGRAM DESCRIPTION
This tool creates the snapshot for single/multiple parts as per input options.
The snapshot contains key point information for each sheet. If 
the snapshot data already exists, it will overwrite the snapshot.
Based on the "Create Overlay Data with Snapshot Data" Customer Default toggle value
this tool also creates overlay data for each sheet.

WHAT DOES THE TOOL DO?

This tool does the following:
  - Loads a part. If this is an assembly part, then the part attempts to partially 
    load the assembly subassemblies and components from the input directories.
  - Updates all the views in the drawing based on the -update option. 
  - Create the key point information for sheets, views, dimensions, notes, 
    feature control frames, datum feature symbols, datum targets, symbols,
    tables, part lists, centerlines, crosshatches.
  - Write the key point information.
  - Create and write the overlay data for all the sheets based on 
    "Create Overlay Data with Snapshot Data" Customer Default toggle value.
  - Save the part.
  - Close the part.


---------------------------------------------------------------------------------
ExecuteCompareReport :
---------------------------------------------------------------------------------

USAGE
The ExecuteCompareReport program compares the drawing data in current part against previously
saved key point information of the current part or saved/new data of another Drawing/Revision.

ExecuteCompareReport <filename> -d <dirname> -subdir -f <Filelist.txt> -t -dbg -l <logfile.txt> 
            -time <timelimit> -TC -u=<username> -p=<password> -update -tol <x.x> -s(save) -of <filename> -c <filename> -cf <FileList.txt> -reuse
   
where:

[<filename>]        : Caches the drafting key point information and CGM data for the part file
                      <filename>.User may give a list of names separated by commas in native mode.
                      For Teamcenter give CLI spec of the top part of master model.
                      CLI spec format : @DB/<MFK ID>/<rev id>
                      Use fnd0partIdentifier property on Item in Teamcenter to get MFK ID.
                      If only Item ID is given, may get "Part not found in database" error. 
[-d]                : Processes all the part files in current work directory.
                      This option is applicable for native mode only.
[-d <dirname>]      : Processes all the part files in the directory <dirname>.
                      This option is applicable for native mode only.
[-subdir]           : Traverses subdirectories for part files.
                      This option is applicable for native mode.
[-f <Filelist.txt>] : Process all the part files in FileList.txt. Part files 
                      are separated by new line. Teamcenter parts are specified 
                      by @DB/<item_id>/<rev_id>/<relation_type>/<dataset_name>.
[-t]                : Shows output on the screen.
[-l <logfile.txt>]  : Outputs log file information to specified log file. If not
                      specified, executecomparereport_log.txt is created in 
                      temporary directory.
[-dbg]              : Logs developer debug information to the syslog.
[-TC]               : Processes in Teamcenter.
[-u=<username>]     : Teamcenter username.
                      This option is applicable for Teamcenter mode only.
[-p=<password>]     : Teamcenter password.
                      This option is applicable for Teamcenter mode only.
[-time <timelimit>] : Process the part files up to the given time limit. 
                      Provide Time in minutes.
[-update]           : Updates all the views in the drawing before running
                      the compare report.
[-tol <x.x>]        : Specify the tolerance which will be used to compare
                      the real numbers.
[-s(save)]          : Saves part file with new compare report overwriting any
                      existing compare report.
[-of <filename>]    : Generates XML file with <filename> that contains summary
                      results of the comparison. This is required input.
                      The system will generate XML file for each part
                      called <partfilename>.xml
 [-c <filename>]    : Compares snapshot from -c <filename> against <filename>
                      snapshot. This option should be used along with
                      <filename> option. User may give a list of names
                      separated by commas in native mode.
                      For Teamcenter give Item ID/CLI spec of top part of master model.
                      CLI spec format : @DB/<MFK ID>/<rev id>
                      If only Item ID is given, may get some error.
[-cf <FileList.txt>]: Compares snapshot from -cf <FileList.txt> against
                      -f <FileList.txt>. This option should be used along
                      with -f <Filelist.txt>. Part files are separated by
                      new line. Teamcenter parts specified by
                      @DB/<item_id>/<rev_id>/<relation_type>/<dataset_name>.
[-reuse]            : Reuses existing snapshot data if present from compare part. 
                      This option is applicable with "-c" or "-cf" .

EXAMPLES OF USAGE
   UNIX   : ExecuteCompareReport -d /parts/ug -subdir -t -dbg -update -tol 0.001 -of /parts/ug/summary.xml
   WINDOWS: ExecuteCompareReport -d D:\parts\ug -subdir -t -dbg -update -tol 0.001 -of D:\parts\ug\summary.xml

   The example above runs the ExecuteCompareReport program on all parts in the
   D:\parts\ug directory and creates compare report.

   UNIX   : ExecuteCompareReport /parts/ug/a.prt -c /parts/ug/b.prt -t -dbg -tol 0.001 -of /parts/ug/summary.xml
   WINDOWS: ExecuteCompareReport D:\parts\ug\a.prt -c D:\parts\ug\b.prt -t -dbg -tol 0.001 -of D:\parts\ug\summary.xml

   The example above runs the ExecuteCompareReport program based on comparison between snapshot from "a.prt" against "b.prt".

PROGRAM DESCRIPTION
This tool creates the compare report for single/multiple parts as per input options.
The compare report contains comparison between current key point information and previously
saved key point information in current part OR comparison between current key point information 
with saved or new key point information (based on -reuse option) from another compare part. 
If previously saved snapshot is not present then this tool will give error. 
If the compare report data already exists, it will overwrite the compare report.

WHAT DOES THE TOOL DO?

This tool does the following:
  - Loads a part. If this is an assembly part, then the part attempts to partially
    load from the input directories.
  - Updates all the view in the drawing based on -update option. 
  - Create the current key point information for sheets, views, dimensions, notes, 
    feature control frames, datum feature symbols, datum targets, symbols,
    tables, part lists, centerlines, crosshatches.
  - Compare the current key point information with saved key point information and 
    creates a compare report.
  - For compare different part case, load the compare part file. Compare the current key point information 
    with saved key point information or new key point information based on reuse option.
  - Save the part based on -save option.
  - Close the part.

NOTE: The CreateSnapshotData and ExecuteCompareReport program will make use of the load options
      specified via the UGII_LOAD_OPTIONS environment variable. If the environment variable is not 
      specified and an assembly part is being used, then the tool will partially load the 
      assembly subassemblies and components from the input directories.
