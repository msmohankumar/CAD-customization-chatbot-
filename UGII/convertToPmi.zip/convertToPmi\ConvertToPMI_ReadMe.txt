ConvertToPMI_ReadMe.txt

OVERVIEW
This ReadMe describes the proper usage of the ConvertToPMI tool.

ENVIRONMENT
To run ConvertToPMI you need to run in an NX UNIX subshell or in
a Command Prompt from NX tools on Windows.

   UNIX:
   In the NX Activity menu go to Administration Utilities-> UNIX SHELL (Start unix subshell)

   WINDOWS:
   Go to NX Tools-> Command Prompt

---------------------------------------------------------------------------------
ConvertToPMI :
---------------------------------------------------------------------------------

USAGE
The ConvertToPMI program allows the conversion drafting views and annotation from a drawing part to the associated model.

ConvertToPMI <drawing> -config <config.def> -LO <load options file> -TC -u=<username> 
             p=<password>  -TA <filename> -NAME <name>  -NUMBER <number> -REV <revision> -DRAFTANN -DRAFTANNDEL

where:

[<drawing>]               : Convert the Drawing Contents to 3D for the specified part file <drawing>.
                            For Teamcenter give CLI spec of the drawing part
                            CLI spec format : @DB/<MFK ID>/<rev id>
                            Use fnd0partIdentifier property on item in teamcenter to get MFK ID required input.

[-config <config.def>]    : Conversion options file path input for conversion operation
                            Optional. If not supplied, default file from installation will be used.

[-LO <load options file>] : Load options file. 
                            Optional. If not specified the ConvertToPMI_load_options.def
                            file shipped with the installation will be used.

[-TC]                     : To process in Teamcenter.
                            Optional. If not specified, part is assumed to be on native file system.

[-u=<username>]           : Teamcenter username.
                            This option is applicable for Teamcenter mode only.
                            Required for Teamcenter conversion.

[-p=<password>]           : Teamcenter password.
                            This option is applicable for Teamcenter mode only.
                            Required for Teamcenter conversion.

[-TA <filename>]          : Specification for the target Assembly if used.
                            Optional: If not specified, part associated with the Drawing will be used.
                            For Teamcenter give CLI spec of the drawing part
                            CLI spec format : @DB/<MFK ID>/<rev id>
                            Use fnd0partIdentifier property on item in teamcenter to get MFK ID required input.

[-NAME name]              : If specified, indicates the target part is saved as a new Item/Rev and
                            specifies the item name.
                            Optional: If not specified, target part is saved using existing part name.

[-NUMBER number           : If specified, indicates the target part is saved as a new Item/Rev and
                            specifies the item number. If "ASSIGN", system will assign new number.
                            Optional: If not specified, target part is saved using existing part number.

[-REV <revision>]         : If specified without item name and number, just a new revision of the
                            target part. If "ASSIGN", system will assign new revision.
                            Optional: If not specified, target part is saved using existing part revision.

[-DRAFTANN]				  :  If specified, considers drafting annotations displayed in 3D models as candidates for conversion.
							Optional: If not specified, drafting annotations displayed in 3D will not be processed for conversion.

[-DRAFTANNDEL]			  : If specified, considers drafting annotations displayed in 3D models as candidates for conversion.
                            After successful conversion, corresponding annotations will be deleted. This option can be provided without specifying "DRAFTANN".
							Optional: If not specified, drafting annotations displayed in 3D will not be processed for conversion.


EXAMPLES OF USAGE
   UNIX   : ConvertToPMI /parts/ug/drawing.prt -TA /parts/ug/TargetAssembly.prt
   WINDOWS: ConvertToPMI D:\parts\ug\drawing.prt -TA D:\parts\ug\TargetAssembly.prt
   
   The example above runs the ConvertToPMI program on drawing.prt part file.
   
        
PROGRAM DESCRIPTION
This tool convert views and annotations to drawing master part or alternate target assembly
if specified.

WHAT DOES THE TOOL DO?

This tool does the following:
  - Loads a part. If this is an assembly part, then loading options will be used to load components.
  - Validate configuration file location if specified. 
  - Validate load options file location if specified. 
  - Convert all sheets, views and annotation from drawing part to master part or alternate target assembly if specified.
  - Save master part or alternate target assebly, in Team Center mode save as alternate target assembly with -NAME, -NUMBER, -REV.
  - Close all parts.

---------------------------------------------------------------------------------
