# File Name:  spinoff_fpam_clone_wnt.pl
#
# REV   AUTHOR         		 DATE          COMMENT
# ===   ======         		=======       =======
#  01   Sandeep Bhole  		01-Feb-2018   initial version
#  02   Purushottam Thakre  05-May-2020	  Resolved issue occurred due to additive template file name modified
# 
# ************************************************************************
#
# Internal script to create fpam inch and metric clone files used for importing
# fpam templates.
#
# This script is called by "tcin_fpam_template_setup.bat" to gather the list of
# fpam template files before importing them into Teamcenter database.
#
# Set UGII_BASE_DIR and UGII_TMP_DIR before executing this script.
# If successful, "nxdm_fpam_template_import_inch.clone" and "nxdm_fpam_template_import_metric.clone" 
# will be created in UGII_TMP_DIR folder.
#
# Copyright 2018
# Siemens Product Lifecycle Management Software Inc. 
# All Rights Reserved
#
#

## Get the environment variables string

$ugii_base_dir = $ENV{UGII_BASE_DIR};
$ugii_tmp_dir = $ENV{UGII_TMP_DIR};

if ($ugii_base_dir eq '')
{
    print "ERROR: UGII_BASE_DIR is not set. \n \n";
    exit 1;
}

if ($ugii_tmp_dir eq '')
{
    print "ERROR: UGII_TMP_DIR is not set. \n \n";
    exit 1;
}

## Get the the NX version string

$num_of_args = $#ARGV + 1;

if ($num_of_args == 0)
{
    print "ERROR: Script has no User argument. \n";
    print "ERROR: Script has no NX version argument. \n \n";
    exit 1;
}

if ($num_of_args == 1)
{
    print "ERROR: Script has no NX version argument. \n \n";
    exit 1;
}

## Input arguments: USER, NX VERSION, and ACTION

$user = $ARGV[0];
$version = $ARGV[1];
$action = "NEW_REVISION";
$revision = "/A";

$action_local = $ARGV[2];
if (index($action_local, "OVERWRITE") > -1)
{
    $action = "OVERWRITE";
}


$mfk_prefix = "";
$mfk_keys = "";
$mfk_suffix = "";

$item_prefix = "";
$item_keys = "";
$item_suffix = "";

printf "number of arguments in spinoff is ";
printf $num_of_args . "\n\n";

if ($num_of_args >= 4)
{
    $keys_local = $ARGV[3];
    $key_idx = index($keys_local, "mfk_keys=");
    if ($key_idx > -1)
    {
        $mfk_substr = substr($keys_local, $key_idx + 9);
        $mfk_prefix = "%#MFK#%,=item_id=";
        if( $mfk_substr =~ /NOKEY/ )
        {
            $mfk_keys = "";
        }
        else
        {
            $mfk_keys = ",$mfk_substr";
        }
        $mfk_suffix = ",object_type=Mea0MEFixPlaneOP";
    }
    else
    {
        # If this isn't an mfk key for the Mea0MEFixPlaneOP type it may be one for the Item type
        $key_idx = index($keys_local, "item_keys=");
        if ($key_idx > -1)
        {
            $item_substr = substr($keys_local, $key_idx + 10);
            $item_prefix = "%#MFK#%,=item_id=";
            if( $item_substr =~ /NOKEY/ )
            {
                $item_keys = "";
            }
            else
            {
                $item_keys = ",$item_substr";
            }
            $item_suffix = ",object_type=Item";
        }
    }
}

## See if there is are mfk keys input for the Item type (target).
## Set up the mfk key strings if there are any
## Set the mfk key strings to empty strings if not

if ($num_of_args == 5)
{
    $keys_local = $ARGV[4];
    $key_idx = index($keys_local, "item_keys=");
    if ($key_idx > -1)
    {
        $item_substr = substr($keys_local, $key_idx + 10);
        $item_prefix = "%#MFK#%,=item_id=";
        if( $item_substr =~ /NOKEY/ )
        {
            $item_keys = "";
        }
        else
        {
            $item_keys = ",$item_substr";
        }
        $item_suffix = ",object_type=Item";
    }
}


# Print 
print "\n\n**** Doing fpam template import pre-processing... \n\n";

# location where native templates are placed
$path_inch_mm = "$ugii_base_dir\\mach\\templates";

#read ugs_additive_manufacturing_templates.pax and search for the Filename and 
#collect in an array

$file_native_additive_template = "$path_inch_mm\\ugs_additive_manufacturing_templates.pax";
open (NAT, "$file_native_additive_template");
$count = 0;
@additivefileNames;
while ( $line = <NAT> )
{
    if (index($line, "<Filename>") > -1)
    {   
       $startPos = index($line, ">") + 1;      
       $endPos = rindex($line, "<");
       $template_name = substr($line, $startPos, $endPos - $startPos );   
       $additivefileNames[$count] =  $template_name;
       ++$count;       
    }
}
close NAT;

#read the template dir
opendir(TEMPLATE_DIR, "$path_inch_mm");
my @files_inch_mm = grep /\.prt$/, readdir(TEMPLATE_DIR);
closedir(TEMPLATE_DIR);


## Start to create the inch clone file

$suffix_inch = "_inch_$version";
$file_inch = "$ugii_tmp_dir\\nxdm_fpam_template_import_inch.clone";
$error = open (FHT, "> $file_inch");
if ($error == 0)
{
    print "ERROR: $file_inch does not have a write access. \n \n";
    exit 1;
}

my $NX_FULL_VERSION=`%UGII_BASE_DIR%\\nxbin\\env_print -n`;

## remove newline from the end of a string
chomp $NX_FULL_VERSION;

## remove dot special character, so NX 9.0.3.4 becomes NX 9034
$NX_FULL_VERSION=~s/\.//g;
## remove space, so NX 9034 becomes NX9034
$NX_FULL_VERSION=~s/ //;

$version_inch = "_inch_$NX_FULL_VERSION";
$version_metric="_metric_$NX_FULL_VERSION";

printf FHT "&LOG Operation_Type: IMPORT_OPERATION\n";
printf FHT "&LOG Default_Cloning_Action: $action\n";
printf FHT "&LOG Default_Naming_Technique: AUTO_GENERATE\n";
printf FHT "&LOG Default_Container: \"$user:$version Fixed Plane Additive Manufacturing Templates\"\n";
printf FHT "&LOG Default_Directory: \"\"\n";
printf FHT "&LOG Default_Part_Type: Item\n";
printf FHT "&LOG Default_Part_Name: \"\"\n";
printf FHT "&LOG Default_Part_Description: \"\"\n";
printf FHT "&LOG Default_Copy_Associated_Files: Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: specification Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: manifestation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: altrep Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: scenario Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: simulation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_motion Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_solution Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_mesh Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_geometry Yes\n";
printf FHT "&LOG Default_Associated_Files_Directory: \"\"\n";
printf FHT "&LOG Default_Validation_Mode: OFF\n";
printf FHT "&LOG\n";

$count = 0;
foreach $file (@files_inch_mm)
{
   $cli_name = $file;
   if ( ( grep /$cli_name/, @additivefileNames ) && (index($cli_name, "_inch_") > -1))
   {
      substr($cli_name, rindex($cli_name, '.'), 4) = "";

      printf FHT "&LOG Part: \"$path_inch_mm\\$file\"\n";
      printf FHT "&LOG Cloning_Action: DEFAULT_DISP\n";
      printf FHT "&LOG Naming_Technique: USER_NAME Clone_Name: \@DB/$mfk_prefix$cli_name$suffix_inch$mfk_keys$mfk_suffix$revision\n";
      printf FHT "&LOG Container: \"$user:$version Fixed Plane Additive Manufacturing Templates\"\n";
      printf FHT "&LOG Part_Type: Mea0MEFixPlaneOP\n";
      printf FHT "&LOG Part_Name: $cli_name$suffix_inch\n";
      printf FHT "&LOG Part_Description: $cli_name$suffix_inch\n";
      printf FHT "&LOG Associated_Files_Directory: \"$path_inch_mm\\$cli_name\"\n";
      printf FHT "&LOG\n";
      ++$count;
   }
}

print "$path_inch_mm contains $count english templates. \n \n";

close FHT;

print "** Successfully created inch clone file. \n";

## Start to create the metric clone file

$suffix_metric = "_metric_$version";
$file_metric = "$ugii_tmp_dir\\nxdm_fpam_template_import_metric.clone";
$error = open (FHT, "> $file_metric");
if ($error == 0)
{
    print "ERROR: $file_metric does not have a write access. \n \n";
    exit 1;
}

printf FHT "&LOG Operation_Type: IMPORT_OPERATION\n";
printf FHT "&LOG Default_Cloning_Action: $action\n";
printf FHT "&LOG Default_Naming_Technique: AUTO_GENERATE\n";
printf FHT "&LOG Default_Container: \"$user:$version Fixed Plane Additive Manufacturing Templates\"\n";
printf FHT "&LOG Default_Directory: \"\"\n";
printf FHT "&LOG Default_Part_Type: Item\n";
printf FHT "&LOG Default_Part_Name: \"\"\n";
printf FHT "&LOG Default_Part_Description: \"\"\n";
printf FHT "&LOG Default_Copy_Associated_Files: Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: specification Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: manifestation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: altrep Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: scenario Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: simulation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_motion Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_solution Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_mesh Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_geometry Yes\n";
printf FHT "&LOG Default_Associated_Files_Directory: \"\"\n";
printf FHT "&LOG Default_Validation_Mode: OFF\n";
printf FHT "&LOG\n";

$count = 0;
foreach $file (@files_inch_mm)
{
  $cli_name = $file;
  if ( ( grep /$cli_name/, @additivefileNames ) && (index($cli_name, "_mm_") > -1))
  {
      $cli_name = $file;
      substr($cli_name, rindex($cli_name, '.'), 4) = "";

      printf FHT "&LOG Part: \"$path_inch_mm\\$file\"\n";
      printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$mfk_prefix$cli_name$suffix_metric$mfk_keys$mfk_suffix$revision\n";
      printf FHT "&LOG Container: \"$user:$version Fixed Plane Additive Manufacturing Templates\"\n";
      printf FHT "&LOG Part_Type: Mea0MEFixPlaneOP\n";
      printf FHT "&LOG Part_Name: $cli_name$suffix_metric\n";
      printf FHT "&LOG Part_Description: $cli_name$suffix_metric\n";
      printf FHT "&LOG Associated_Files_Directory: \"$path_inch_mm\\$cli_name\"\n";
      printf FHT "&LOG\n";
      ++$count;
  }
}
print "$path_inch_mm contains $count metric templates. \n \n";

close FHT;

print "** Successfully created metric clone file. \n";

exit 0;
