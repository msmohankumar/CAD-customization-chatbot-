# File Name:  spinoff_new_inspection_clone_wnt.pl
# Version: 01
# Date: 26-Oct-2017
# 
# ************************************************************************
#
# Internal script to create inspection inch and metric clone files used for importing
# inspection templates.
#
# This script is called by "tcin_inspection_template_setup.bat" to gather the list of
# inspection template files before importing them into Teamcenter database.
#
# Set UGII_BASE_DIR, UGII_TMP_DIR, and UGII_CMM_DIR before executing this script.
# If successful, "nxdm_inspection_template_import_inch.clone" and "nxdm_cam_template_import_metric.clone" 
# will be created in UGII_TMP_DIR folder.
#
# Ex. perl spinoff_inspection_clone_wnt.pl infodba NX75 NEW_REVISION
#     where infodba is the Teamcenter User ID, NX75 is the NX version, NEW_REVISION/OVERWRITE is the action
# 
# Copyright 2017, 2018 
# Siemens Product Lifecycle Management Software Inc. 
# All Rights Reserved
#
#
# ************************************************************************
# Revision History:
#
# REV   AUTHOR        DATE          COMMENT
# ===   ======        =======       =======
#  01   Bruce Hwang 26-Oct-2017   cloned from spinoff_inspection_clone_wnt.pl
# $HISTORY$
# ************************************************************************
#
#

## Get the environment variables string

$ugii_base_dir = $ENV{UGII_BASE_DIR};
$ugii_tmp_dir = $ENV{UGII_TMP_DIR};
$ugii_cmm_dir = $ENV{UGII_CMM_DIR};

if ($ugii_base_dir eq '')
{
	print "ERROR: UGII_BASE_DIR is not set. \n \n";
	exit 1;
}

if ($ugii_tmp_dir eq '')
{
	print "ERROR: UGII_TMP_DIR is not set. \n \n";
	exit 1;
}

## Get the the NX version string

$num_of_args = $#ARGV + 1;

if ($num_of_args == 0)
{
	print "ERROR: Script has no User argument. \n";
	print "ERROR: Script has no NX version argument. \n \n";
	exit 1;
}

if ($num_of_args == 1)
{
	print "ERROR: Script has no NX version argument. \n \n";
	exit 1;
}

## Input arguments: USER, NX VERSION, and ACTION

$user = $ARGV[0];
$version = $ARGV[1];
$action = "NEW_REVISION";
$revision = "/A";

if ($num_of_args >= 3)
{
	$action_local = $ARGV[2];
	if (index($action_local, "OVERWRITE") > -1)
	{
		$action = "OVERWRITE";
	}
}

## See if there is are mfk keys input for the Mfg0CMMInspMEOP type or the Item type.
## Set up the mfk key strings if there are any
## Set the mfk key strings to empty strings if not

$mfk_prefix = "";
$mfk_keys = "";
$mfk_suffix = "";

$item_prefix = "";
$item_keys = "";
$item_suffix = "";

if ($num_of_args >= 4)
{
    $keys_local = $ARGV[3];
    $key_idx = index($keys_local, "mfk_keys=");
    if ($key_idx > -1)
    {
        $mfk_substr = substr($keys_local, $key_idx + 9);
        $mfk_prefix = "%#MFK#%,=item_id=";
        if( $mfk_substr =~ /NOKEY/ )
        {
            $mfk_keys = "";
        }
        else
        {
            $mfk_keys = ",$mfk_substr";
        }
        $mfk_suffix = ",object_type=Mfg0CMMInspMEOP";
    }
    else
    {
        # If this isn't an mfk key for the Mfg0CMMInspMEOP type it may be one for the Item type
        $key_idx = index($keys_local, "item_keys=");
        if ($key_idx > -1)
        {
            $item_substr = substr($keys_local, $key_idx + 10);
            $item_prefix = "%#MFK#%,=item_id=";
            if( $item_substr =~ /NOKEY/ )
            {
                $item_keys = "";
            }
            else
            {
                $item_keys = ",$item_substr";
            }
            $item_suffix = ",object_type=Item";
        }
    }
}

## See if there is are mfk keys input for the Item type (target).
## Set up the mfk key strings if there are any
## Set the mfk key strings to empty strings if not

if ($num_of_args >= 5)
{
    $keys_local = $ARGV[4];
    $key_idx = index($keys_local, "item_keys=");
    if ($key_idx > -1)
    {
        $item_substr = substr($keys_local, $key_idx + 10);
        $item_prefix = "%#MFK#%,=item_id=";
        if( $item_substr =~ /NOKEY/ )
        {
            $item_keys = "";
        }
        else
        {
            $item_keys = ",$item_substr";
        }
        $item_suffix = ",object_type=Item";
    }
}


# Define the constants

$suffix_inch = "_inch";
$path_inch = "$ugii_cmm_dir\\cmm_inspection\\resource\\template_part\\english";
$file_inch = "$ugii_tmp_dir\\nxdm_inspection_template_import_inch.clone";
@files_inch = <$ugii_cmm_dir\\cmm_inspection\\resource\\template_part\\english\\*.prt >;

$suffix_metric = "_metric";
$path_metric = "$ugii_cmm_dir\\cmm_inspection\\resource\\template_part\\metric";
$file_metric = "$ugii_tmp_dir\\nxdm_inspection_template_import_metric.clone";
@files_metric = <$ugii_cmm_dir\\cmm_inspection\\resource\\template_part\\metric\\*.prt >;

## Start to create the clone file

# print "** Creating $file_inch... \n";

$error = open (FHT, "> $file_inch");

if ($error == 0)
{
	print "ERROR: $file_inch does not have a write access. \n \n";
	exit 1;
}


printf FHT "&LOG Operation_Type: IMPORT_OPERATION\n";
printf FHT "&LOG Default_Cloning_Action: $action\n";
printf FHT "&LOG Default_Naming_Technique: AUTO_TRANSLATE\n";
printf FHT "&LOG Default_Container: \"infodba:CMM Inspection Setup Templates\"\n";
printf FHT "&LOG Default_Directory: \"\"\n";
printf FHT "&LOG Default_Part_Type: Mfg0CMMInspMEOP\n";
printf FHT "&LOG Default_Part_Name: \"\"\n";
printf FHT "&LOG Default_Part_Description: \"\"\n";
printf FHT "&LOG Default_Copy_Associated_Files: Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: specification Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: manifestation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: altrep Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: scenario Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: simulation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_motion Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_solution Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_mesh Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_geometry Yes\n";
printf FHT "&LOG Default_Associated_Files_Directory: \"\"\n";
printf FHT "&LOG Default_Validation_Mode: OFF\n";
printf FHT "&LOG\n";

$count =1;


foreach $file (@files_inch)
{
	if (index($file, "_target") > -1)
	{
		$part_index = rindex($file, "\\");
		$file_name = substr($file, $part_index+1);
		$cli_name = $file_name;
		substr($cli_name, rindex($cli_name, '.'), 4) = "";

		printf FHT "&LOG Part: \"$path_inch\\$file_name\"\n";
		printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$item_prefix$cli_name$suffix_inch$item_keys$item_suffix$revision\n";
		printf FHT "&LOG Container: \"infodba:CMM Inspection Setup Templates\"\n";
		printf FHT "&LOG Part_Type: Item\n";
		printf FHT "&LOG Part_Name: $cli_name$suffix_inch\n";
		printf FHT "&LOG Part_Description: $cli_name$suffix_inch\n";
		printf FHT "&LOG Associated_Files_Directory: \"$path_inch\\$cli_name\"\n";
		printf FHT "&LOG\n";

		$count = $count + 1;
	}
}

foreach $file (@files_inch)
{
	if (index($file, "_target") < 0)
	{
		$part_index = rindex($file, "\\");
		$file_name = substr($file, $part_index+1);
		$cli_name = $file_name;
		substr($cli_name, rindex($cli_name, '.'), 4) = "";

		printf FHT "&LOG Part: \"$path_inch\\$file_name\"\n";
		printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$mfk_prefix$cli_name$suffix_inch$mfk_keys$mfk_suffix$revision\n";
		printf FHT "&LOG Container: \"infodba:CMM Inspection Setup Templates\"\n";
		printf FHT "&LOG Part_Type: Mfg0CMMInspMEOP\n";
		printf FHT "&LOG Part_Name: $cli_name$suffix_inch\n";
		printf FHT "&LOG Part_Description: $cli_name$suffix_inch\n";
		printf FHT "&LOG Associated_Files_Directory: \"$path_inch\\$cli_name\"\n";
		printf FHT "&LOG\n";

		$count = $count + 1;
	}
}

close FHT;

# print "** Successfully created $file_inch. \n";


## Create metric clone file

# print "** Creating $file_metric... \n";

$error = open (FHT, "> $file_metric");

if ($error == 0)
{
	print "ERROR: $file_metric does not have a write access. \n \n";
	exit 1;
}

printf FHT "&LOG Operation_Type: IMPORT_OPERATION\n";
printf FHT "&LOG Default_Cloning_Action: $action\n";
printf FHT "&LOG Default_Naming_Technique: AUTO_TRANSLATE\n";
printf FHT "&LOG Default_Container: \"infodba:CMM Inspection Setup Templates\"\n";
printf FHT "&LOG Default_Directory: \"\"\n";
printf FHT "&LOG Default_Part_Type: Mfg0CMMInspMEOP\n";
printf FHT "&LOG Default_Part_Name: \"\"\n";
printf FHT "&LOG Default_Part_Description: \"\"\n";
printf FHT "&LOG Default_Copy_Associated_Files: Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: specification Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: manifestation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: altrep Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: scenario Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: simulation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_motion Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_solution Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_mesh Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_geometry Yes\n";
printf FHT "&LOG Default_Associated_Files_Directory: \"\"\n";
printf FHT "&LOG Default_Validation_Mode: OFF\n";
printf FHT "&LOG\n";

foreach $file (@files_metric)
{
	if (index($file, "_target") > -1)
	{
		$part_index = rindex($file, "\\");
		$file_name = substr($file, $part_index+1);
		$cli_name = $file_name;
		substr($cli_name, rindex($cli_name, '.'), 4) = "";

		printf FHT "&LOG Part: \"$path_metric\\$file_name\"\n";
		printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$item_prefix$cli_name$suffix_metric$item_keys$item_suffix$revision\n";
		printf FHT "&LOG Container: \"infodba:CMM Inspection Setup Templates\"\n";
		printf FHT "&LOG Part_Type: Item\n";
		printf FHT "&LOG Part_Name: $cli_name$suffix_metric\n";
		printf FHT "&LOG Part_Description: $cli_name$suffix_metric\n";
		printf FHT "&LOG Associated_Files_Directory: \"$path_metric\\$cli_name\"\n";
		printf FHT "&LOG\n";

		$count = $count + 1;
	}
}

foreach $file (@files_metric)
{
	if (index($file, "_target") < 0)
	{
		$part_index = rindex($file, "\\");
		$file_name = substr($file, $part_index+1);
		$cli_name = $file_name;
		substr($cli_name, rindex($cli_name, '.'), 4) = "";

		printf FHT "&LOG Part: \"$path_metric\\$file_name\"\n";
		printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$mfk_prefix$cli_name$suffix_metric$mfk_keys$mfk_suffix$revision\n";
		printf FHT "&LOG Container: \"infodba:CMM Inspection Setup Templates\"\n";
		printf FHT "&LOG Part_Type: Mfg0CMMInspMEOP\n";
		printf FHT "&LOG Part_Name: $cli_name$suffix_metric\n";
		printf FHT "&LOG Part_Description: $cli_name$suffix_metric\n";
		printf FHT "&LOG Associated_Files_Directory: \"$path_metric\\$cli_name\"\n";
		printf FHT "&LOG\n";

		$count = $count + 1;
	}
}

close FHT;

# print "** Successfully created $file_metric. \n \n";

exit 0;
