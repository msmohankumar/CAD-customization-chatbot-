# File Name:  spinoff_fpam_paxfiles_wnt.pl
#
# REV   AUTHOR         DATE          COMMENT
# ===   ======         =======       =======
#  01   Sandeep Bhole  01-Feb-2018   Clone from spinoff_cam_paxfiles_wnt.pl
# ************************************************************************
#
# This script will create the NXDM pax files from the native pax files.
#


system "copy \"%UGII_BASE_DIR%\"\\MACH\\templates\\ugs_additive_manufacturing*.pax .";

@files = <ugs_additive_manufacturing*.pax>;

open (FH, "nxdm_fpam_template_import_all.clone");
$count = 0;
@osName;
%osNameToCliNameHash;
while ( $line = <FH> )
{
    if (index($line, "Part:") > -1)
    {
        $s = rindex($line, "\\"); 
        if ( $s > -1)
        {
            #<ingle> 08-Sep-2011 PR#5803598, PR#5792013
            # Creating a hash array of OS Names and the corresponding CLI Names
            $osName[$count] =  substr($line, -((length $line)-$s)+1, -2);
            $line = <FH>;

            $s = rindex($line, "\@DB");
            $temp = "\\". substr($line, -((length $line) -$s), -1);
            #<ingle> 08-Sep-2011PR#5803598, PR#5792013
            # Incase the CLI Name in the nxdm_template_import.clone is in quotes it needs to be stripped of them
            if($temp[$temp - 1] == "\"")
            {
                $temp=~ s/"$// ;
            }
            $osNameToCliNameHash{$osName[$count]}[0] =  $temp;
            ++$count;
        }
    }
}
#<ingle> 08-Sep-2011 PR#5803598, PR#5792013
# Sorting the OS Names Array in decreasing order of length,
# this way the first OS Name processed during search and replace cannot be a subset of any other OS Name
@sortedOSName = sort{$a cmp $b} @osName;

for ($i=0; $i<$count;$i++)
{
        foreach $file (@files)
        {
            #<ingle> 08-Sep-2011 PR#5803598, PR#5792013
            #Replacing OS Names with CLI Names in each of the pax files
            $os = $sortedOSName[$i];
            $cli = $osNameToCliNameHash{$sortedOSName[$i]}[0];
            system "perl -i.bak -p -e s?$os?$cli?g $file";
        }
}

close FH;

foreach $file (@files)
{
    open (FH, $file);
    open (TH, "> nxdm_$file");
    
    $tabUsesMM = 0;
    $objectUsesMM = 0;

    while ( $line = <FH> )
    {
        if ($tabUsesMM)
        {
            if (index($line, "<UsesMasterModel>Yes") > -1)
            {
                $objectUsesMM = 1;
            }
        }

        if (index($line, "FileNewTab") > -1)
        {
            $line =~ s?/>? Environment=\"Managed\"/>?;

            if (index($line, "UsesMasterModel=\"Yes\"") > -1)
            {
                $tabUsesMM = 1;
            }
        }

        if (index($line, "/ObjectData") > -1)
        {
              #<8gh3j3> 06-12-2013 using user specified item type in the template entries
             
            # remove the "-t[ype]=" from the string before we use it
            $typestr = $ARGV[0];
            $idx = index($ARGV[0], "=");
            if ($idx > -1)
            {
                $typestr = substr( $ARGV[0], $idx + 1);
            }

            printf TH "             <ItemType>".$typestr."</ItemType>\n";

            # <gigeart> We always want master and never want specification
            if (($tabUsesMM) && ($objectUsesMM))
            {
                printf TH "        <RelationType>master</RelationType>\n";
            }
            else
            {
                printf TH "        <RelationType>master</RelationType>\n";
            }

            $objectUsesMM = 0;
        }

        # <gigeart> We need to change the LibraryClassPath
        if (index($line, "<LibraryClassPath>GENERAL") > -1)
        {

            printf TH "            <LibraryClassPath>SETUP_TEMPLATE;GENERAL</LibraryClassPath>\n"
        }
        else
        {
            printf TH $line;
        }

    }

    close FH;
    close TH;
}

