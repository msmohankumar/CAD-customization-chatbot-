# File Name:  spinoff_paxfiles_wnt.pl
# 
# ************************************************************************
#
# This script will create the NXDM pax files from the native pax files.
#
# Copyright (c) 1997, 2006
# UGS Corporation
# All Rights Reserved
#
#
# ************************************************************************
# Revision History:
#
# REV   AUTHOR      DATE      COMMENT
# ===   ======      =======   =======
# 18-Oct-2006  Dave Larson             Initial create
# 27-Nov-2006  Dave Larson             perl specific adjustments for TC_ROOT/IMAN_ROOT path perl
# 11-Dec-2006  Dave Larson             made some copy file exhancements
# 07-Sep-2011  Kedar Ingle             PR#5803598, PR#5792013 Fix: changed the filename replace logic for ugs* pax file spinoff
# 19-12-2013   Kirthi Kanth G          Using user specified item type in the template entries
# 07-Aug-2014  Kedar Ingle             PR#6950431: Untabifying the script
# 14-May-2015  Rahul Jawalge           ARCH11323:Added check,If dir exist then only move pax
# $HISTORY$
# ************************************************************************

#<ingle> 08-Sep-2011 PR#5803598
# Accomodating for spaces in the NX Installation path.
system "copy \"%UGII_BASE_DIR%\"\\ugii\\templates\\ugs*.pax .";

if( -d "$ENV{UGII_BASE_DIR}/simulation/templates" )
{
    system "copy \"%UGII_BASE_DIR%\"\\simulation\\templates\\ugs*.pax .";
}

if( -d "$ENV{UGII_BASE_DIR}/mach/templates" )
{
    system "copy \"%UGII_BASE_DIR%\"\\mach\\templates\\ugs*.pax .";
}

if( -d "$ENV{UGII_BASE_DIR}/cmm_inspection/templates" )
{
    system "copy \"%UGII_BASE_DIR%\"\\cmm_inspection\\templates\\ugs*.pax .";
}

@files = <ugs*.pax>;

open (FH, "nxdm_template_import.clone");
$count = 0;
@osName;
%osNameToCliNameHash;
while ( $line = <FH> )
{
    if (index($line, "Part:") > -1)
    {
        $s = rindex($line, "\\"); 
        if ( $s > -1)
        {
            #<ingle> 08-Sep-2011 PR#5803598, PR#5792013
            # Creating a hash array of OS Names and the corresponding CLI Names
            $osName[$count] =  substr($line, -((length $line)-$s)+1, -2);
            $line = <FH>;

            $s = rindex($line, "\@DB");
            $temp = "\\". substr($line, -((length $line) -$s), -1);
            #<ingle> 08-Sep-2011PR#5803598, PR#5792013
            # Incase the CLI Name in the nxdm_template_import.clone is in quotes it needs to be stripped of them
            if($temp[$temp - 1] == "\"")
            {
                $temp=~ s/"$// ;
            }
            $osNameToCliNameHash{$osName[$count]}[0] =  $temp;
            ++$count;
        }
    }
}
#<ingle> 08-Sep-2011 PR#5803598, PR#5792013
# Sorting the OS Names Array in decreasing order of length,
# this way the first OS Name processed during search and replace cannot be a subset of any other OS Name
@sortedOSName = sort{$a cmp $b} @osName;
for ($i=0; $i<$count;$i++)
{
        foreach $file (@files)
        {
            #<ingle> 08-Sep-2011 PR#5803598, PR#5792013
            #Replacing OS Names with CLI Names in each of the pax files
            $os = $sortedOSName[$i];
            $cli = $osNameToCliNameHash{$sortedOSName[$i]}[0];
            system "perl -i.bak -p -e s?$os?$cli?g $file";
        }
}
close FH;

foreach $file (@files)
{
    open (FH, $file);
    open (TH, "> nxdm_$file");
    
    $tabUsesMM = 0;
    $objectUsesMM = 0;

    while ( $line = <FH> )
    {
        if ($tabUsesMM)
        {
            if (index($line, "<UsesMasterModel>Yes") > -1)
            {
                $objectUsesMM = 1;
            }
        }

        if (index($line, "FileNewTab") > -1)
        {
            $line =~ s?/>? Environment=\"Managed\"/>?;

            if (index($line, "UsesMasterModel=\"Yes\"") > -1)
            {
                $tabUsesMM = 1;
            }
        }

        if (index($line, "/ObjectData") > -1)
        {
            #<8gh3j3> 06-12-2013 using user specified item type in the template entries
            printf TH "        <ItemType>".$ARGV[0]."</ItemType>\n";

            if (($tabUsesMM) && ($objectUsesMM))
            {
                printf TH "        <RelationType>specification</RelationType>\n";
            }
            else
            {
                printf TH "        <RelationType>master</RelationType>\n";
            }
            $objectUsesMM = 0;
        }
        printf TH $line;
    }
    close FH;
    close TH;
}

