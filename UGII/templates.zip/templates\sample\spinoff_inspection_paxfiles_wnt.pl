# File Name:  spinoff_paxfiles_wnt.pl
# 
# ************************************************************************
#
# This script will create the NXDM pax files from the native pax files.
#
# Copyright (c) 1997, 2006
# UGS Corporation
# All Rights Reserved
#
#
# ************************************************************************
# Revision History:
#
# REV   AUTHOR      DATE      COMMENT
# ===   ======      =======   =======
# 27-Jan-2014  Thomas Gigear           Clone from spinoff_paxfiles_wnt.pl
# 27-Nov-2018  Thomas Gigear           The pax file is in the cmm_inspection\templates dir
# $HISTORY$
# ************************************************************************

#<ingle> 08-Sep-2011 PR#5803598
# Accomodating for spaces in the NX Installation path.
system "copy \"%UGII_BASE_DIR%\"\\cmm_inspection\\templates\\ugs_inspection*.pax .";

@files = <ugs_inspection*.pax>;

open (FH, "nxdm_inspection_template_import_all.clone");
$count = 0;
@osName;
%osNameToCliNameHash;
while ( $line = <FH> )
{

	if (index($line, "Part:") > -1)
	{
		$s = rindex($line, "\\"); 
		if ( $s > -1)
		{
			#<ingle> 08-Sep-2011 PR#5803598, PR#5792013
			# Creating a hash array of OS Names and the corresponding CLI Names
			$osName[$count] =  substr($line, -((length $line)-$s)+1, -2);
			$line = <FH>;

			$s = rindex($line, "\@DB");
			$temp = "\\". substr($line, -((length $line) -$s), -1);
			#<ingle> 08-Sep-2011PR#5803598, PR#5792013
			# Incase the CLI Name in the nxdm_template_import.clone is in quotes it needs to be stripped of them
			if($temp[$temp - 1] == "\"")
			{
				$temp=~ s/"$// ;
			}
			$osNameToCliNameHash{$osName[$count]}[0] =  $temp;
			++$count;
		}
	}
}
#<ingle> 08-Sep-2011 PR#5803598, PR#5792013
# Sorting the OS Names Array in decreasing order of length,
# this way the first OS Name processed during search and replace cannot be a subset of any other OS Name
@sortedOSName = sort{$a cmp $b} @osName;

for ($i=0; $i<$count;$i++)
{
		foreach $file (@files)
		{
			#<ingle> 08-Sep-2011 PR#5803598, PR#5792013
			#Replacing OS Names with CLI Names in each of the pax files
			$os = $sortedOSName[$i];
			$cli = $osNameToCliNameHash{$sortedOSName[$i]}[0];
			system "perl -i.bak -p -e s?$os?$cli?g $file";
		}
}

foreach $file (@files)
{
    #<gigeart> replace dat file
    $olddat = "inspection_general.dat";
    $newdat = "inspection_teamcenter_general.dat";
    system "perl -i.bak -p -e s?$olddat?$newdat?g $file";
}

close FH;

foreach $file (@files)
{
	open (FH, $file);
	open (TH, "> nxdm_$file");
	
	$tabUsesMM = 0;
	$objectUsesMM = 0;

	while ( $line = <FH> )
	{
		if ($tabUsesMM)
		{
			if (index($line, "<UsesMasterModel>Yes") > -1)
			{
				$objectUsesMM = 1;
			}
		}

		if (index($line, "FileNewTab") > -1)
		{
			$line =~ s?/>? Environment=\"Managed\"/>?;

			if (index($line, "UsesMasterModel=\"Yes\"") > -1)
			{
				$tabUsesMM = 1;
			}
		}

		if (index($line, "/ObjectData") > -1)
		{
              #<8gh3j3> 06-12-2013 using user specified item type in the template entries
             
            # remove the "-t[ype]=" from the string before we use it
            $typestr = $ARGV[0];
            $idx = index($ARGV[0], "=");
            if ($idx > -1)
            {
                $typestr = substr( $ARGV[0], $idx + 1);
            }

			printf TH "        <ItemType>".$typestr."</ItemType>\n";

            # <gigeart> We always want master and never want specification
			if (($tabUsesMM) && ($objectUsesMM))
			{
				printf TH "        <RelationType>master</RelationType>\n";
			}
			else
			{
				printf TH "        <RelationType>master</RelationType>\n";
			}

			$objectUsesMM = 0;
		}

        # <gigeart> We need to change the LibraryClassPath
        if (index($line, "<LibraryClassPath>GENERAL") > -1)
        {

            printf TH "            <LibraryClassPath>SETUP_TEMPLATE;GENERAL</LibraryClassPath>\n"
        }
        # If this is a file from the English diretory and it got a "_metric" appended, the appended text needs to be
        # changed to "_inch"
        elsif ( (index($line, "Filename") > -1) && (index($line, "UGII_INSPECTION_TEMPLATE_PART_ENGLISH_DIR") > -1) && (index($line, "_metric") > -1 ) )
        {
            $modline = $line;
            $modline =~ s/_metric/_inch/;
            printf TH $modline;
        }
        else
        {
		    printf TH $line;
        }

	}

	close FH;
	close TH;
}

foreach $file (@files)
{
    #<gigeart> remove metric template directory environment variables
    $oldstr = '\x3cFilename\x3e\${UGII_INSPECTION_TEMPLATE_PART_METRIC_DIR}';
    $newstr = '\x3cFilename\x3e';
    system "perl -i.bak -p -e s?$oldstr?$newstr?g nxdm_$file";
}

foreach $file (@files)
{
    #<gigeart> remove english template directory environment variables
    $oldstr = '\x3cFilename\x3e\${UGII_INSPECTION_TEMPLATE_PART_ENGLISH_DIR}';
    $newstr = '\x3cFilename\x3e';
    system "perl -i.bak -p -e s?$oldstr?$newstr?g nxdm_$file";
}

