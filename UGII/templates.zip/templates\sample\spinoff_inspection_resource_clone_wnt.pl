# File Name:  spinoff_inspection_resource_clone_wnt.pl
# Version: 03
# Date: 07-Nov-2011
# 
# ************************************************************************
#
# Internal script to create a clone file used for importing inspection resources
#
# This script is called by "inspection_cmm_import_setup.bat", "inspection_device_import_setup.bat"
# and "inspection_probe_import_setup.bat to gather the list of
# inspection resource files before importing them into Teamcenter database.
#
# Set UGII_BASE_DIR, UGII_TMP_DIR, and UGII_CMM_DIR before executing this script.
# If successful, "nxdm_cmm_resource_import.clone"  
# will be created in UGII_TMP_DIR folder.
#
# Ex. perl spinoff_inspection_clone_wnt.pl infodba NX75 NEW_REVISION CONTAINER DIR MFKKEYS
#     where infodba is the Teamcenter User ID, NX75 is the NX version, NEW_REVISION/OVERWRITE is the action
# 
# Copyright 2010, 2014 
# Siemens Product Lifecycle Management Software Inc. 
# All Rights Reserved
#
#
# ************************************************************************
# Revision History:
#
# REV   AUTHOR        DATE          COMMENT
# ===   ======        =======       =======
#  01   Thomas Gigear 14-MAR-2014   cloned from spinoff_inspection_clone_wnt.pl
# $HISTORY$
# ************************************************************************
#
#

## Get the environment variables string

$ugii_base_dir = $ENV{UGII_BASE_DIR};
$ugii_tmp_dir = $ENV{UGII_TMP_DIR};
$ugii_cmm_dir = $ENV{UGII_CMM_DIR};

if ($ugii_base_dir eq '')
{
	print "ERROR: UGII_BASE_DIR is not set. \n \n";
	exit 1;
}

if ($ugii_tmp_dir eq '')
{
	print "ERROR: UGII_TMP_DIR is not set. \n \n";
	exit 1;
}

## Get the the NX version string

$num_of_args = $#ARGV + 1;

if ($num_of_args < 5)
{
	print "ERROR: Not enough arguments. \n \n";
	exit 1;
}

## Input arguments: USER, NX VERSION, and ACTION

$user = $ARGV[0];
$version = $ARGV[1];
$action = "NEW_REVISION";
$revision = "/A";

$action_local = $ARGV[2];
if (index($action_local, "OVERWRITE") > -1)
{
	$action = "OVERWRITE";
}

$container = $ARGV[3];
$input_dir = $ARGV[4];

## See if there is are mfk keys input.
## Set up the mfk key strings if there are any
## Set the mfk key strings to empty strings if not

$mfk_prefix = "";
$mfk_keys = "";
$mfk_suffix = "";

if ($num_of_args >= 6)
{
    $keys_local = $ARGV[5];
    $key_idx = index($keys_local, "mfk_keys=");
    if ($key_idx > -1)
    {
        $mfk_substr = substr($keys_local, $key_idx + 9);
        $mfk_prefix = "%#MFK#%,=item_id=";
        if( $mfk_substr =~ /NOKEY/ )
        {
            $mfk_keys = "";
        }
        else
        {
            $mfk_keys = ",$mfk_substr";
        }
        $mfk_suffix = ",object_type=Item";
    }
}


# Define the constants

$clone_file = "$ugii_tmp_dir\\nxdm_inspection_resource_import.clone";
@files_input = <$input_dir\\*.prt >;

## Start to create the clone file

# print "** Creating $clone_file... \n";

$error = open (FHT, "> $clone_file");

if ($error == 0)
{
	print "ERROR: $clone_file does not have a write access. \n \n";
	exit 1;
}


printf FHT "&LOG Operation_Type: IMPORT_OPERATION\n";
printf FHT "&LOG Default_Cloning_Action: $action\n";
printf FHT "&LOG Default_Naming_Technique: AUTO_TRANSLATE\n";
printf FHT "&LOG Default_Container: \"$container\"\n";
printf FHT "&LOG Default_Directory: \"\"\n";
printf FHT "&LOG Default_Part_Type: Item\n";
printf FHT "&LOG Default_Part_Name: \"\"\n";
printf FHT "&LOG Default_Part_Description: \"\"\n";
printf FHT "&LOG Default_Copy_Associated_Files: Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: specification Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: manifestation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: altrep Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: scenario Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: simulation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_motion Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_solution Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_mesh Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_geometry Yes\n";
printf FHT "&LOG Default_Associated_Files_Directory: \"\"\n";
printf FHT "&LOG Default_Validation_Mode: OFF\n";
printf FHT "&LOG\n";

$count =1;


foreach $file (@files_input)
{
	$part_index = rindex($file, "\\");
	$file_name = substr($file, $part_index+1);
	$cli_name = $file_name;
	substr($cli_name, rindex($cli_name, '.'), 4) = "";

	printf FHT "&LOG Part: \"$input_dir\\$file_name\"\n";
	printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \"\@DB/$mfk_prefix$cli_name$suffix_inch$mfk_keys$mfk_suffix$revision\"\n";
	printf FHT "&LOG Container: \"$container\"\n";
	printf FHT "&LOG Part_Type: Item\n";
	printf FHT "&LOG Part_Name: \"$cli_name\"\n";
	printf FHT "&LOG Part_Description: \"$cli_name\"\n";
	printf FHT "&LOG Associated_Files_Directory: \"$input_dir\\$cli_name\"\n";
	printf FHT "&LOG\n";

	$count = $count + 1;
}

close FHT;

# print "** Successfully created $clone_file. \n";

exit 0;
