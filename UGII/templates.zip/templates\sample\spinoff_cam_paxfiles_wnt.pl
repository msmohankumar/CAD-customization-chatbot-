# File Name:  spinoff_cam_paxfiles_wnt.pl
# 
# ************************************************************************
#
# This script will create the NXDM pax files from the native pax files.
#
# Copyright (c) 2014
# Siemens Product Lifecycle Management Software Inc.
# All Rights Reserved
#
#
# ************************************************************************
# Revision History:
#
# DATE            AUTHOR              COMMENT
# 02-Apr-2014   Bruce Hwang           Clone from spinoff_inspection_paxfiles_wnt.pl
# 23-Apr-2014   Bruce Hwang           PR#7133056 remove OS folder names from pax file
# 03-Jun-2014   Bruce Hwang           PR#7143805 add missing data to pax file - libref, type template, description
# 09-Apr-2021   Bruce Hwang  10016140 Take perl from TC root
# $HISTORY$
# ************************************************************************


# Accomodating for spaces in the NX Installation path.
system "copy \"%UGII_BASE_DIR%\"\\ugii\\templates\\sample\\nxdm_ugs_manufacturing_templates_sample.pax nxdm_ugs_manufacturing_templates.pax";

@files = <nxdm_ugs_manufacturing_templates.pax>;

open (FH, "nxdm_cam_template_import_all.clone");
$count = 0;
@idName;
%idToMfkIdHash;
while ( $line = <FH> )
{
    # first, look for MFK ID in clone file
    if (index($line, "USER_NAME Clone_Name: ") > -1)
    {
        $s = rindex($line, "\@DB");
        # find the MFK ID
        $tempMFK = "\\". substr($line, -((length $line) -$s), -1);
        # remove "@DB\
        $temp = substr($tempMFK, 5);
        # move to the Part_Name field
        $line = <FH>;  ## Container
        $line = <FH>;  ## Part_Type
        $line = <FH>;  ## Part_Name
        if(index($line, "Part_Name: ") > -1)
	{
	    # Creating a hash array of non-MFK ID and the corresponding MFK ID
            $tmpID = substr($line, 16, -1);

            $idName[$count] = $tmpID . "/A";
	    # Incase the CLI Name in the nxdm_template_import.clone is in quotes it needs to be stripped of them
	    if($temp[$temp - 1] == "\"")
	    {
	       	$temp=~ s/"$// ;
	    }
            # save id to MFK Id hash
	    $idToMfkIdHash{$idName[$count]}[0] =  $temp;

	    ++$count;
	}
    }
}


# Sorting the ID Names Array in decreasing order of length,
# this way the first OS Name processed during search and replace cannot be a subset of any other ID Name
@sortedId = sort{$a cmp $b} @idName;

for ($i=0; $i<$count;$i++)
{
    foreach $file (@files)
    {
        #Replacing OS Names with CLI Names in each of the pax files
	$os = $sortedId[$i];
	$cli = $idToMfkIdHash{$sortedId[$i]}[0];
	system "%TC_ROOT%\\perl\\bin\\perl -i.bak -p -e s?$os?$cli?g $file";
    }
}

close FH;






