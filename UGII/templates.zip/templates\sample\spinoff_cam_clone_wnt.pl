# File Name:  spinoff_cam_clone_wnt.pl
#
# REV   AUTHOR        DATE          COMMENT
# ===   ======        =======       =======
#  01   Chunsik Yi    06-May-2011   Fix the import problem caused by a folder name containing blank spaces
#  02   Bruce Hwang   02-Apr-2014   Enhance this script to support MFK - Nulti-Field Key project
#  03   Bruce Hwang   11-Aug-2014   PR2235308 Consider setup templates under "updates" folder
#  04   Bruce Hwang   03-Nov-2014   PR7223271 Don't take patch string since it may contain un-necessary data.
#  05   Prashant Sisodiya 19-Mar-2015 ARCH11323: Changed path to UGII_BASE_DIR\nxbin
# 
# ************************************************************************
#
# Internal script to create CAM inch and metric clone files used for importing
# CAM templates.
#
# This script is called by "tcin_cam_template_setup.bat" to gather the list of
# CAM template files before importing them into Teamcenter database.
#
# Set UGII_BASE_DIR and UGII_TMP_DIR before executing this script.
# If successful, "nxdm_cam_template_import_inch.clone" and "nxdm_cam_template_import_metric.clone" 
# will be created in UGII_TMP_DIR folder.
#
#  For example, in a default domain (ie, there is no extra key in MENCMachining and Item).
#  perl spinoff_cam_clone_wnt.pl infodba NX75 NEW_REVISION 
#     where infodba is the Teamcenter User ID, NX75 is the NX version, NEW_REVISION/OVERWRITE is the action,
#
#  For example, MENCMachining and Item have the extra key owning_user=AWSJtlqVx6sBFD
#  perl spinoff_cam_clone_wnt.pl infodba NX75 NEW_REVISION -mfk_keys=owning_user=AWSJtlqVx6sBFD -item_keys=owning_user=AWSJtlqVx6sBFD
#     where infodba is the Teamcenter User ID, NX75 is the NX version, NEW_REVISION/OVERWRITE is the action, 
#                   and owning_user=AWSJtlqVx6sBFD is the extra key to MENCMachining and Item object.
# 
# Copyright 2014
# Siemens Product Lifecycle Management Software Inc. 
# All Rights Reserved
#
#

## Get the environment variables string

$ugii_base_dir = $ENV{UGII_BASE_DIR};
$ugii_tmp_dir = $ENV{UGII_TMP_DIR};

if ($ugii_base_dir eq '')
{
	print "ERROR: UGII_BASE_DIR is not set. \n \n";
	exit 1;
}

if ($ugii_tmp_dir eq '')
{
	print "ERROR: UGII_TMP_DIR is not set. \n \n";
	exit 1;
}

## Get the the NX version string

$num_of_args = $#ARGV + 1;

if ($num_of_args == 0)
{
	print "ERROR: Script has no User argument. \n";
	print "ERROR: Script has no NX version argument. \n \n";
	exit 1;
}

if ($num_of_args == 1)
{
	print "ERROR: Script has no NX version argument. \n \n";
	exit 1;
}

## Input arguments: USER, NX VERSION, and ACTION

$user = $ARGV[0];
$version = $ARGV[1];
$action = "NEW_REVISION";
$revision = "/A";

$action_local = $ARGV[2];
if (index($action_local, "OVERWRITE") > -1)
{
    $action = "OVERWRITE";
}


$mfk_prefix = "";
$mfk_keys = "";
$mfk_suffix = "";

$item_prefix = "";
$item_keys = "";
$item_suffix = "";

printf "number of arguments in spinoff is ";
printf $num_of_args . "\n\n";

if ($num_of_args >= 4)
{
    $keys_local = $ARGV[3];
    $key_idx = index($keys_local, "mfk_keys=");
    if ($key_idx > -1)
    {
        $mfk_substr = substr($keys_local, $key_idx + 9);
        $mfk_prefix = "%#MFK#%,=item_id=";
        if( $mfk_substr =~ /NOKEY/ )
        {
            $mfk_keys = "";
        }
        else
        {
            $mfk_keys = ",$mfk_substr";
        }
        $mfk_suffix = ",object_type=MENCMachining";
    }
    else
    {
        # If this isn't an mfk key for the MENCMachining type it may be one for the Item type
        $key_idx = index($keys_local, "item_keys=");
        if ($key_idx > -1)
        {
            $item_substr = substr($keys_local, $key_idx + 10);
            $item_prefix = "%#MFK#%,=item_id=";
            if( $item_substr =~ /NOKEY/ )
            {
                $item_keys = "";
            }
            else
            {
                $item_keys = ",$item_substr";
            }
            $item_suffix = ",object_type=Item";
        }
    }
}

## See if there is are mfk keys input for the Item type (target).
## Set up the mfk key strings if there are any
## Set the mfk key strings to empty strings if not

if ($num_of_args == 5)
{
    $keys_local = $ARGV[4];
    $key_idx = index($keys_local, "item_keys=");
    if ($key_idx > -1)
    {
        $item_substr = substr($keys_local, $key_idx + 10);
        $item_prefix = "%#MFK#%,=item_id=";
        if( $item_substr =~ /NOKEY/ )
        {
            $item_keys = "";
        }
        else
        {
            $item_keys = ",$item_substr";
        }
        $item_suffix = ",object_type=Item";
    }
}


# Print 
print "\n\n**** Doing CAM template import pre-processing... \n\n";

# Define the constants

$suffix_inch = "_inch_$version";
$path_inch = "$ugii_base_dir\\mach\\resource\\template_part\\english";
$file_inch = "$ugii_tmp_dir\\nxdm_cam_template_import_inch.clone";

opendir(INCH_TEMPLATE_DIR, "$path_inch");
my @files_inch = grep /\.prt$/, readdir(INCH_TEMPLATE_DIR);
closedir(INCH_TEMPLATE_DIR);

my $number_of_inch_templates = scalar (@files_inch);
print "$path_inch contains $number_of_inch_templates templates. \n \n";

$suffix_metric = "_metric_$version";
$path_metric = "$ugii_base_dir\\mach\\resource\\template_part\\metric";
$file_metric = "$ugii_tmp_dir\\nxdm_cam_template_import_metric.clone";

opendir(METRIC_TEMPLATE_DIR, "$path_metric");
my @files_metric = grep /\.prt$/, readdir(METRIC_TEMPLATE_DIR);
closedir(METRIC_TEMPLATE_DIR);

my $number_of_metric_templates = scalar (@files_metric);
print "$path_metric contains $number_of_metric_templates templates. \n \n";

## Start to create the clone file

# print "** Creating $file_inch... \n";

$error = open (FHT, "> $file_inch");

if ($error == 0)
{
	print "ERROR: $file_inch does not have a write access. \n \n";
	exit 1;
}


my $NX_FULL_VERSION=`%UGII_BASE_DIR%\\nxbin\\env_print -n`;


## remove newline from the end of a string
chomp $NX_FULL_VERSION;

## remove dot special character, so NX 9.0.3.4 becomes NX 9034
$NX_FULL_VERSION=~s/\.//g;
## remove space, so NX 9034 becomes NX9034
$NX_FULL_VERSION=~s/ //;

$version_inch = "_inch_$NX_FULL_VERSION";
$version_metric="_metric_$NX_FULL_VERSION";


printf FHT "&LOG Operation_Type: IMPORT_OPERATION\n";
printf FHT "&LOG Default_Cloning_Action: $action\n";
printf FHT "&LOG Default_Naming_Technique: AUTO_GENERATE\n";
printf FHT "&LOG Default_Container: \"$user:$version CAM Setup Templates\"\n";
printf FHT "&LOG Default_Directory: \"\"\n";
printf FHT "&LOG Default_Part_Type: Item\n";
printf FHT "&LOG Default_Part_Name: \"\"\n";
printf FHT "&LOG Default_Part_Description: \"\"\n";
printf FHT "&LOG Default_Copy_Associated_Files: Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: specification Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: manifestation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: altrep Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: scenario Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: simulation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_motion Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_solution Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_mesh Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_geometry Yes\n";
printf FHT "&LOG Default_Associated_Files_Directory: \"\"\n";
printf FHT "&LOG Default_Validation_Mode: OFF\n";
printf FHT "&LOG\n";

$count =1;

foreach $file (@files_inch)
{
	if ((index($file, "_target") > -1) && (index($file, "simulation_") < 0))
	{
		$cli_name = $file;
		substr($cli_name, rindex($cli_name, '.'), 4) = "";

		printf FHT "&LOG Part: \"$path_inch\\$file\"\n";
		printf FHT "&LOG Cloning_Action: DEFAULT_DISP\n";
		printf FHT "&LOG Naming_Technique: USER_NAME Clone_Name: \@DB/$item_prefix$cli_name$suffix_inch$item_keys$item_suffix$revision\n";
		printf FHT "&LOG Container: \"$user:$version CAM Setup Templates\"\n";
		printf FHT "&LOG Part_Type: Item\n";
		printf FHT "&LOG Part_Name: $cli_name$suffix_inch\n";
		printf FHT "&LOG Part_Description: $cli_name$suffix_inch\n";
		printf FHT "&LOG Associated_Files_Directory: \"$path_inch\\$cli_name\"\n";
		printf FHT "&LOG\n";

		$count = $count + 1;
	}
}

foreach $file (@files_inch)
{
	if ((index($file, "_target") < 0) && (index($file, "simulation_") < 0))
	{
		$cli_name = $file;
		substr($cli_name, rindex($cli_name, '.'), 4) = "";

		printf FHT "&LOG Part: \"$path_inch\\$file\"\n";
		printf FHT "&LOG Cloning_Action: DEFAULT_DISP\n";
		printf FHT "&LOG Naming_Technique: USER_NAME Clone_Name: \@DB/$mfk_prefix$cli_name$suffix_inch$mfk_keys$mfk_suffix$revision\n";
		printf FHT "&LOG Container: \"$user:$version CAM Setup Templates\"\n";
		printf FHT "&LOG Part_Type: MENCMachining\n";
		printf FHT "&LOG Part_Name: $cli_name$suffix_inch\n";
		printf FHT "&LOG Part_Description: $cli_name$suffix_inch\n";
		printf FHT "&LOG Associated_Files_Directory: \"$path_inch\\$cli_name\"\n";
		printf FHT "&LOG\n";

		$count = $count + 1;
	}
}

close FHT;


$updateWord = "_Update";

## Consider inch setup templates under "updates" folder

$folder_update_inch = "$ugii_base_dir\\mach\\updates\\template_part\\english";
$file_update_inch = "$ugii_tmp_dir\\nxdm_cam_template_import_update_inch.clone";

opendir(UPDATE_INCH_TEMPLATE_DIR, "$folder_update_inch");
my @update_files_inch = grep /\.prt$/, readdir(UPDATE_INCH_TEMPLATE_DIR);
closedir(UPDATE_INCH_TEMPLATE_DIR);

my $number_of_update_inch_templates = scalar (@update_files_inch);

if($number_of_update_inch_templates > 0)
{
    print "$folder_update_inch contains $number_of_update_inch_templates templates. \n \n";

    open (FHU, "$update_files_inch");
    $error = open (FHT, "> $file_update_inch");
    
    if ($error == 0)
    {
	print "ERROR: $file_update_inch does not have a write access. \n \n";
	exit 1;
    }
    
    printf FHT "&LOG Operation_Type: IMPORT_OPERATION\n";
    printf FHT "&LOG Default_Cloning_Action: $action\n";
    printf FHT "&LOG Default_Naming_Technique: AUTO_GENERATE\n";
    printf FHT "&LOG Default_Container: \"$user:$version CAM Setup Templates\"\n";
    printf FHT "&LOG Default_Directory: \"\"\n";
    printf FHT "&LOG Default_Part_Type: Item\n";
    printf FHT "&LOG Default_Part_Name: \"\"\n";
    printf FHT "&LOG Default_Part_Description: \"\"\n";
    printf FHT "&LOG Default_Copy_Associated_Files: Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: specification Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: manifestation Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: altrep Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: scenario Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: simulation Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: cae_motion Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: cae_solution Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: cae_mesh Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: cae_geometry Yes\n";
    printf FHT "&LOG Default_Associated_Files_Directory: \"\"\n";
    printf FHT "&LOG Default_Validation_Mode: OFF\n";
    printf FHT "&LOG\n";

    foreach $fileUpdate (@update_files_inch)
    {
	if ((index($fileUpdate, "_target") > -1) && (index($fileUpdate, "simulation_") < 0))
	{
            $cli_name = $fileUpdate;
            substr($cli_name, rindex($cli_name, '.'), 4) = "";
            
            printf FHT "&LOG Part: \"$folder_update_inch\\$fileUpdate\"\n";
## a "_Update" will be placed after item ID; for example DieMold_Express_target_inch_NX9_Update
            printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$item_prefix$cli_name$suffix_inch$updateWord$item_keys$item_suffix$revision\n";
            printf FHT "&LOG Container: \"$user:$version CAM Setup Templates\"\n";
            printf FHT "&LOG Part_Type: Item\n";

            printf FHT "&LOG Part_Name: $cli_name$suffix_inch$updateWord\n";
            printf FHT "&LOG Part_Description: $cli_name$version_inch\n";
            printf FHT "&LOG Associated_Files_Directory: \"$path_inch\\$cli_name\"\n";
            printf FHT "&LOG\n";
            
            $count = $count + 1;
	}
    }
    foreach $fileUpdate (@update_files_inch)
    {
        if ((index($fileUpdate, "_target") < 0) && (index($fileUpdate, "simulation_") < 0))
        {
            $cli_name = $fileUpdate;
            substr($cli_name, rindex($cli_name, '.'), 4) = "";
            
            printf FHT "&LOG Part: \"$folder_update_inch\\$fileUpdate\"\n";
## a "_Update" will be placed after item ID; for example DieMold_Express_inch_NX9_Update
            printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$mfk_prefix$cli_name$suffix_inch$updateWord$mfk_keys$mfk_suffix$revision\n";
            printf FHT "&LOG Container: \"$user:$version CAM Setup Templates\"\n";
            printf FHT "&LOG Part_Type: MENCMachining\n";
            printf FHT "&LOG Part_Name: $cli_name$suffix_inch$updateWord\n";
            printf FHT "&LOG Part_Description: $cli_name$version_inch\n";
            printf FHT "&LOG Associated_Files_Directory: \"$path_inch\\$cli_name\"\n";
            printf FHT "&LOG\n";
        }
    }
    close FHU;
    close FHT;
}

# print "** Successfully created $file_inch. \n";


## Create metric clone file

# print "** Creating $file_metric... \n";

$error = open (FHT, "> $file_metric");

if ($error == 0)
{
	print "ERROR: $file_metric does not have a write access. \n \n";
	exit 1;
}

printf FHT "&LOG Operation_Type: IMPORT_OPERATION\n";
printf FHT "&LOG Default_Cloning_Action: $action\n";
printf FHT "&LOG Default_Naming_Technique: AUTO_GENERATE\n";
printf FHT "&LOG Default_Container: \"$user:$version CAM Setup Templates\"\n";
printf FHT "&LOG Default_Directory: \"\"\n";
printf FHT "&LOG Default_Part_Type: Item\n";
printf FHT "&LOG Default_Part_Name: \"\"\n";
printf FHT "&LOG Default_Part_Description: \"\"\n";
printf FHT "&LOG Default_Copy_Associated_Files: Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: specification Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: manifestation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: altrep Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: scenario Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: simulation Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_motion Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_solution Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_mesh Yes\n";
printf FHT "&LOG Default_Non_Master_Copy: cae_geometry Yes\n";
printf FHT "&LOG Default_Associated_Files_Directory: \"\"\n";
printf FHT "&LOG Default_Validation_Mode: OFF\n";
printf FHT "&LOG\n";

foreach $file (@files_metric)
{
	if ((index($file, "_target") > -1) && (index($file, "simulation_") < 0))
	{
		$cli_name = $file;
		substr($cli_name, rindex($cli_name, '.'), 4) = "";

		printf FHT "&LOG Part: \"$path_metric\\$file\"\n";
		printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$item_prefix$cli_name$suffix_metric$item_keys$item_suffix$revision\n";
		printf FHT "&LOG Container: \"$user:$version CAM Setup Templates\"\n";
		printf FHT "&LOG Part_Type: Item\n";
		printf FHT "&LOG Part_Name: $cli_name$suffix_metric\n";
		printf FHT "&LOG Part_Description: $cli_name$suffix_metric\n";
		printf FHT "&LOG Associated_Files_Directory: \"$path_metric\\$cli_name\"\n";
		printf FHT "&LOG\n";

		$count = $count + 1;
	}
}

foreach $file (@files_metric)
{
	if ((index($file, "_target") < 0) && (index($file, "simulation_") < 0))
	{
		$cli_name = $file;
		substr($cli_name, rindex($cli_name, '.'), 4) = "";

		printf FHT "&LOG Part: \"$path_metric\\$file\"\n";
		printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$mfk_prefix$cli_name$suffix_metric$mfk_keys$mfk_suffix$revision\n";
		printf FHT "&LOG Container: \"$user:$version CAM Setup Templates\"\n";
		printf FHT "&LOG Part_Type: MENCMachining\n";
		printf FHT "&LOG Part_Name: $cli_name$suffix_metric\n";
		printf FHT "&LOG Part_Description: $cli_name$suffix_metric\n";
		printf FHT "&LOG Associated_Files_Directory: \"$path_metric\\$cli_name\"\n";
		printf FHT "&LOG\n";

		$count = $count + 1;
	}
}

close FHT;

## Consider metric setup templates under "updates" folder

$folder_update_metric = "$ugii_base_dir\\mach\\updates\\template_part\\metric";
$file_update_metric = "$ugii_tmp_dir\\nxdm_cam_template_import_update_metric.clone";
opendir(UPDATE_METRIC_TEMPLATE_DIR, "$folder_update_metric");
my @update_files_metric = grep /\.prt$/, readdir(UPDATE_METRIC_TEMPLATE_DIR);
closedir(UPDATE_METRIC_TEMPLATE_DIR);

my $number_of_update_metric_templates = scalar (@update_files_metric);


if($number_of_update_metric_templates > 0)
{
    print "$folder_update_metric contains $number_of_update_metric_templates templates. \n \n";

    open (FHU, "$update_files_metric");
    $error = open (FHT, "> $file_update_metric");
    
    if ($error == 0)
    {
	print "ERROR: $file_update_metric does not have a write access. \n \n";
	exit 1;
    }
    printf FHT "&LOG Operation_Type: IMPORT_OPERATION\n";
    printf FHT "&LOG Default_Cloning_Action: $action\n";
    printf FHT "&LOG Default_Naming_Technique: AUTO_GENERATE\n";
    printf FHT "&LOG Default_Container: \"$user:$version CAM Setup Templates\"\n";
    printf FHT "&LOG Default_Directory: \"\"\n";
    printf FHT "&LOG Default_Part_Type: Item\n";
    printf FHT "&LOG Default_Part_Name: \"\"\n";
    printf FHT "&LOG Default_Part_Description: \"\"\n";
    printf FHT "&LOG Default_Copy_Associated_Files: Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: specification Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: manifestation Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: altrep Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: scenario Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: simulation Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: cae_motion Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: cae_solution Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: cae_mesh Yes\n";
    printf FHT "&LOG Default_Non_Master_Copy: cae_geometry Yes\n";
    printf FHT "&LOG Default_Associated_Files_Directory: \"\"\n";
    printf FHT "&LOG Default_Validation_Mode: OFF\n";
    printf FHT "&LOG\n";

    foreach $fileUpdate (@update_files_metric)
    {
	if ((index($fileUpdate, "_target") > -1) && (index($fileUpdate, "simulation_") < 0))
	{
            $cli_name = $fileUpdate;
            substr($cli_name, rindex($cli_name, '.'), 4) = "";
            
            printf FHT "&LOG Part: \"$folder_update_metric\\$fileUpdate\"\n";
## a "_Update" will be placed after item ID; for example DieMold_Express_target_metric_NX9_Update
            printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$item_prefix$cli_name$suffix_metric$updateWord$item_keys$item_suffix$revision\n";
            printf FHT "&LOG Container: \"$user:$version CAM Setup Templates\"\n";
            printf FHT "&LOG Part_Type: Item\n";
            printf FHT "&LOG Part_Name: $cli_name$suffix_metric$updateWord\n";
            printf FHT "&LOG Part_Description: $cli_name$version_metric\n";
            printf FHT "&LOG Associated_Files_Directory: \"$path_inch\\$cli_name\"\n";
            printf FHT "&LOG\n";
        }
    }

    foreach $fileUpdate (@update_files_metric)
    {
        if ((index($fileUpdate, "_target") < 0) && (index($fileUpdate, "simulation_") < 0))
        {
            $cli_name = $fileUpdate;
            substr($cli_name, rindex($cli_name, '.'), 4) = "";

            printf FHT "&LOG Part: \"$folder_update_metric\\$fileUpdate\"\n";
## a "_Update" will be placed after item ID; for example DieMold_Express_metric_NX9_Update
            printf FHT "&LOG Cloning_Action: DEFAULT_DISP Naming_Technique: USER_NAME Clone_Name: \@DB/$mfk_prefix$cli_name$suffix_metric$updateWord$mfk_keys$mfk_suffix$revision\n";
            printf FHT "&LOG Container: \"$user:$version CAM Setup Templates\"\n";
            printf FHT "&LOG Part_Type: MENCMachining\n";
            printf FHT "&LOG Part_Name: $cli_name$suffix_metric$updateWord\n";
            printf FHT "&LOG Part_Description: $cli_name$version_metric\n";
            printf FHT "&LOG Associated_Files_Directory: \"$path_metric\\$cli_name\"\n";
            printf FHT "&LOG\n";
        }
    }
    close FHU;
    close FHT;
}


# print "** Successfully created $file_metric. \n \n";

exit 0;
