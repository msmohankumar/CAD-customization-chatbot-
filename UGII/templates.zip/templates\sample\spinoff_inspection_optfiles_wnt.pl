# File Name:  spinoff_paxfiles_wnt.pl
# 
# ************************************************************************
#
# This script will create the Teamcenter opt file from the original opt file.
#
# Copyright (c) 2014
# UGS Corporation
# All Rights Reserved
#
#
# ************************************************************************
# Revision History:
#
# REV   AUTHOR      DATE      COMMENT
# ===   ======      =======   =======
# 10-Mar-2014  Thomas Gigear           Clone from spinoff_inspection_paxfiles_wnt.pl
# $HISTORY$
# ************************************************************************

#<ingle> 08-Sep-2011 PR#5803598
# Accomodating for spaces in the NX Installation path.
system "copy \"%UGII_BASE_DIR%\"\\cmm_inspection\\resource\\template_set\\inspection_general.opt .";

$file = "inspection_general.opt";
$new_file = "inspection_teamcenter_general.opt";

open (FH, "nxdm_inspection_template_import_all.clone");
$count = 0;
@osName;
%osNameToCliNameHash;
while ( $line = <FH> )
{

	if (index($line, "Part:") > -1)
	{
		$s = rindex($line, "\\"); 
		if ( $s > -1)
		{
			#<ingle> 08-Sep-2011 PR#5803598, PR#5792013
			# Creating a hash array of OS Names and the corresponding CLI Names
			$osName[$count] =  substr($line, -((length $line)-$s)+1, -2);
			$line = <FH>;

			$s = rindex($line, "\@DB");
			$temp = "\\". substr($line, -((length $line) -$s), -1);
			#<ingle> 08-Sep-2011PR#5803598, PR#5792013
			# Incase the CLI Name in the nxdm_template_import.clone is in quotes it needs to be stripped of them
			if($temp[$temp - 1] == "\"")
			{
				$temp=~ s/"$// ;
			}
			$osNameToCliNameHash{$osName[$count]}[0] =  $temp;
			++$count;
		}
	}
}
#<ingle> 08-Sep-2011 PR#5803598, PR#5792013
# Sorting the OS Names Array in decreasing order of length,
# this way the first OS Name processed during search and replace cannot be a subset of any other OS Name
@sortedOSName = sort{$a cmp $b} @osName;

for ($i=0; $i<$count;$i++)
{
	#Replacing OS Names with CLI Names in the opt file
	$os = $sortedOSName[$i];
	$cli = $osNameToCliNameHash{$sortedOSName[$i]}[0];
	system "perl -i.bak -p -e s?$os?$cli?g $file";
}

close FH;

open (FH, $file);
open (TH, "> $new_file");
	
while ( $line = <FH> )
{
    # Copy the lines but remove the native directory env var
    $idx = index($line, "}");
	if ($idx > -1)
	{
        $new_str = substr( $line, $idx + 1);
        printf TH $new_str;
	}
    else
    {
		printf TH $line;
    }

}

close FH;
close TH;


