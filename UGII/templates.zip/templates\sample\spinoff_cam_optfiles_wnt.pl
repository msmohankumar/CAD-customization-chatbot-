# File Name:  spinoff_cam_optfiles_wnt.pl
# 
# ************************************************************************
#
# This script will create the Teamcenter opt file from the original opt file.
#
# Copyright (c) 2014
# Siemens Product Lifecycle Management Software Inc.
# All Rights Reserved
#
#
# ************************************************************************
# Revision History:
#
#  DATE           AUTHOR             COMMENT
# 02-Apr-2014  Bruce Hwang           Clone from spinoff_inspection_optfiles_wnt.pl
# 09-Apr-2021  Bruce Hwang  10016140 Take perl from TC root
# $HISTORY$
# ************************************************************************

# Accomodating for spaces in the NX Installation path.
system "copy \"%UGII_BASE_DIR%\"\\mach\\resource\\template_set\\cam_general.opt cam_teamcenter_general_tmp.opt";

$file_tmp = "cam_teamcenter_general_tmp.opt";
$file_tmp_unit = "cam_teamcenter_general_tmp_unit.opt";
$file = "cam_general.opt";
$new_file = "cam_teamcenter_general.opt";

open (TMH, $file_tmp);
open (FH, "> $file_tmp_unit");
while ( $line = <TMH> )
{
    # ignore comment
    if(index($line, "#") == -1)
    {
      #  printf $line . "\n";
        if(index($line, "ENGLISH") > -1)
        {
            # english part
            # replace .prt with _inch            
            $line =~ s/\.prt/_inch/;
            printf FH $line;
        }
        elsif(index($line, "METRIC") > -1)
        {
            # metric part
            # replace .prt with _metric
            $line =~ s/\.prt/_metric/;
            printf FH $line;
        }
       
    }
}
close TMH;
close FH;

system "copy cam_teamcenter_general_tmp_unit.opt cam_general.opt";

open (FH, "nxdm_cam_template_import_all.clone");
$count = 0;
@osName;
%osNameToCliNameHash;
while ( $line = <FH> )
{

	if (index($line, "Part:") > -1)
	{
                # english or metric
                $u = index($line, "english");

		$s = rindex($line, "\\"); 
		if ( $s > -1)
		{
			# Creating a hash array of OS Names and the corresponding CLI Names
			$osName[$count] =  substr($line, -((length $line)-$s)+1, -2);

			$line = <FH>;

			$s = rindex($line, "\@DB");
			$temp = "\\". substr($line, -((length $line) -$s), -1);
                       
			# Incase the CLI Name in the nxdm_template_import.clone is in quotes it needs to be stripped of them
			if($temp[$temp - 1] == "\"")
			{
				$temp=~ s/"$// ;
			}
                        if($u > -1)
                        {
                            $osName[$count] =~ s/\.prt/_inch/;
                        }
                        else
                        {
                            $osName[$count] =~ s/\.prt/_metric/;
                        }

			$osNameToCliNameHash{$osName[$count]}[0] =  $temp;
			++$count;
		}
	}
}

# Sorting the OS Names Array in decreasing order of length,
# this way the first OS Name processed during search and replace cannot be a subset of any other OS Name
@sortedOSName = sort{$a cmp $b} @osName;

for ($i=0; $i<$count;$i++)
{
	#Replacing OS Names with CLI Names in the opt file
	$os = $sortedOSName[$i];
	$cli = $osNameToCliNameHash{$sortedOSName[$i]}[0];
	system "%TC_ROOT%\\perl\\bin\\perl -i.bak -p -e s?$os?$cli?g $file";
}

close FH;

open (FH, $file);
open (TH, "> $new_file");
	
while ( $line = <FH> )
{
    # printf $line . " list line \n";
    # Copy the lines but remove the native directory env var
    $idx = index($line, "}");
	if ($idx > -1)
	{
        $new_str = substr( $line, $idx + 1);
        printf TH $new_str;
	}
    else
    {
		printf TH $line;
    }

}

close FH;
close TH;


