﻿/*=================================================================================================

                        Copyright (c) 2020 Siemens.
                          All rights reserved


=================================================================================================*/

"use strict";

window.editor = ace.edit("editor");
window.errorConsole = ace.edit("errorConsole");
window.currentDocument = "";

let editorRatio = 0.7;

// Setting options for ace editor
window.editor.setOptions({
    theme: "ace/theme/textmate",
    readOnly: false,
    showPrintMargin: false,
    showFoldWidgets: false,
    showLineNumbers: true,
    hScrollBarAlwaysVisible: false,
    vScrollBarAlwaysVisible: false,
    animatedScroll: true,
    dragEnabled: true,
});

// Set font size of ace editor
window.editor.setFontSize(12);
// Replace Ctrl+L with Ctrl+G for gotoline. Note: This will not work from NX, we still need goToLine
window.editor.commands.bindKey({ win: "Ctrl-L", mac: "Command-L" }, null);
window.editor.commands.bindKey({ win: "Ctrl-G", mac: "Command-G" }, "gotoline");


// Setting options for ace editor
window.errorConsole.setOptions({
    theme: "ace/theme/github",
    readOnly: true,
    showPrintMargin: false,
    showFoldWidgets: false,
    showLineNumbers: false,
    hScrollBarAlwaysVisible: false,
    vScrollBarAlwaysVisible: false,
    animatedScroll: true,
    dragEnabled: false,
});

// Set font size of ace editor
window.errorConsole.setFontSize(12);
// Replace Ctrl+L with Ctrl+G for gotoline. Note: This will not work from NX, we still need goToLine
window.errorConsole.commands.bindKey({ win: "Ctrl-L", mac: "Command-L" }, null);
window.errorConsole.commands.bindKey({ win: "Ctrl-G", mac: "Command-G" }, "gotoline");


// Do nothing when 'Esc' is pressed
window.editor.commands.addCommand({
    name: 'DoNothingWhenPressESC',
    bindKey: { win: 'ESC', mac: 'ESC' },
    exec: function () {
        return false;
    },
    readOnly: true
});

// Set the theme to the appropriate one, namely Dark Mode or not.
external.splmHostMethod('getAceTheme', '',
    (returnValue) => {
        window.editor.setTheme(returnValue);
        window.errorConsole.setTheme(returnValue);
    }
);

// Resize the editor with repect to the size of window and size of sidenaviagtor
window.addEventListener('resize', function (event) {
    // <Mike Brown> 24-Sep-2017
    // Fix size of Editor within div editorFrame

    const wrapperHeight = document.getElementById('editorAndConsole').clientHeight;
    const newEditorHeight = Math.floor(wrapperHeight * editorRatio);

    setSliderPosition(newEditorHeight);
});


// Trigger when the editor is changed
window.editor.on("change", function(event) {
    // Update NX about the editor change
    notifyFileUpdate();
});


// Add hotkeys for Save, Save As, New File, and Open. Prevent the event from propagating further.
document.addEventListener('keydown', function (event) {
    // 83 is s
    if (event.ctrlKey === true && event.which === 83)
    {
        event.preventDefault();
        if (event.shiftKey)
        {
            external.splmHostMethod('saveJournalAs', '');
        }
        else
        {
            external.splmHostMethod('saveJournal', '');
        }
    }
    // 78 is n
    if (event.ctrlKey === true && event.which === 78)
    {
        event.preventDefault();
        external.splmHostMethod('newJournal', '');
    }
    // 79 is o
    if (event.ctrlKey === true && event.which === 79)
    {
        event.preventDefault();
        external.splmHostMethod('openJournal', '');
    }
});

// Prevent browser from any action for mousewheelscroll+ctrl 
document.addEventListener('mousewheel DOMMouseScroll', function (event) {
    if (event.ctrlKey === true)
    {
        event.preventDefault();
    }
});


// Handle when the divider is dragged.
function divMove(event) {
    // Stop highlighting in the editor then set the slider position.
    // This ensures the slider moves without the text behind it highlighting
    event.stopPropagation();
    setSliderPosition(event.clientY, true);
}

// Add listener for slider selection to resize side-navigator
// This is run when the mouse is pressed down on the slider
document.getElementById('slider').addEventListener('mousedown', function (event) {

    // Add event listener for mouse movement when the slider is pressed on
    // This tracks the mouse movement when the slider is held down
    window.addEventListener('mousemove', divMove, true);

    // Add event listener that waits until the mouse is no longer held down
    window.addEventListener('mouseup', function (event) {

        // Remove event listener for mouse movement after the mouse is no longer pressed down
        // The slider no longer moves along with the mouse
        window.removeEventListener('mousemove', divMove, true);
    });
});

// Handle a double click on the Ace Editor in error console
document.getElementById('errorConsole').addEventListener('dblclick', function (event) {
    event.preventDefault();
    // Get the row that the cursor was place on during the first click and its text
    const clickedLine = window.errorConsole.getCursorPosition().row;
    const lineText = window.errorConsole.getSession().getDocument().getLine(clickedLine);

    // Search for the number in the line's text
    const regOut = lineText.match(/Line\s+(.*)\s+:/);

    // This does the same thing as above, I'm unsure which is better if either
    //const regOut = /Line\s+(.*)\s+:/.exec(lineText);
    if (regOut) {

        // The match is always element 0 and the (.*) will be element 1
        // There was some random-ish behavior. Casting to a Number fixed this.
        const errorLine = Number(regOut[1]);

        // Scroll to the correct line in the Journal Ace Editor
        window.editor.scrollToLine(errorLine, true, true, function () { });
        window.editor.gotoLine(errorLine, 0, true);
        window.editor.selection.selectLine();

        // Do not set focus so that users can copy from the error console
        //window.editor.focus();
    }
});


function isTextBoxFocused() {
    let focusedElement = document.querySelector(":focus");
    return focusedElement.classList.contains("ace_text-input");
}

function isSearchBoxFocused() {
    let focusedElement = document.querySelector(":focus");
    return focusedElement.classList.contains("ace_search_field");
}

function isPromptContainerFocused() {
    return getActiveElement().classList.contains("ace_prompt_container");
}

// Returns true if the primary editor is currently focused/active within the webpage.
function isEditorActive() {
    let element = getActiveElement();
    return element && element.id === "editor";
}

// Returns true if the error console is currently focused/active within the webpage.
function isErrorConsoleActive() {
    let element = getActiveElement();
    return element && element.id === "errorConsole";
}

// Cancel default context menu
window.oncontextmenu = function (event) {
    event.preventDefault();

    // Encode a payload containing the screen location for the JournalEditor
    let payload = {
        screenX: event.screenX,
        screenY: event.screenY
    };

    // Undo
    payload.canUndo = false;
    // Always enable Undo for Search Boxes
    if (isSearchBoxFocused() || isPromptContainerFocused()) {
        // Yes
        payload.canUndo = true;
    }
    // Enable Undo for the Ace Editor in the Journal Editor if it has Undo.
    else if (isTextBoxFocused() && isEditorActive() && window.editor.getSession().getUndoManager().hasUndo()) {
        // Yes
        payload.canUndo = true;
    }
    // // Do not enable Undo in the Ace Editor in the Error Console
    //else if (isTextBoxFocused() && isErrorConsoleActive()) {
    //    // No
    //    canUndo = false;
    //}

    // Do not enable Delete in the Ace Editor in the Error Console
    // Tell the Journal Editor if the area is Read Only. This will be used to disable certain options.
    payload.isReadOnly = false;
    if (isTextBoxFocused() && isErrorConsoleActive()) {
        payload.isReadOnly = true;
    }

    const payloadString = JSON.stringify(payload);

    // Lauch the popup menu from nx
    external.splmHostMethod('launchPopupMenu', payloadString);

    return false;
}


function getActiveElement() {
    let element = document.activeElement;
    while (element !== null) {
        if (element.id === "editor") {
            break;
        }
        else if (element.id === "errorConsole") {
            break;
        }
        else if (element.classList.contains("ace_prompt_container")) {
            break;
        }

        element = element.parentElement;
    }

    return element;
}

// Resize the journal editor and error console with respect to movement of slider
function setSliderPosition(position, setRatio) {
    const minDivSize = 100;

    // Set the Editor's height based on the ratio it had prior to the move.
    const editor_div = document.getElementById('editor');
    const containerHeight = document.getElementById('editorAndConsole').clientHeight;

    // If the Editor or ErrorConsole is smaller than the minimum size, set them to the minimum size.
    let newEditorBottom = containerHeight - position;
    if (newEditorBottom > containerHeight - minDivSize)
    {
        newEditorBottom = containerHeight - minDivSize;
    }

    if (newEditorBottom < minDivSize)
    {
        newEditorBottom = minDivSize;
    }

    editor_div.style.bottom = newEditorBottom + 'px';
    window.editor.resize();

    // Move the slider to the new position
    const slider_div = document.getElementById('slider');
    slider_div.style.top = containerHeight - newEditorBottom + 'px';

    // Set the top of the Error Console to the new position
    const errorConsole_div = document.getElementById('errorConsole');
    errorConsole_div.style.top = containerHeight - newEditorBottom + 'px';
    window.errorConsole.resize();

    // If the slider bar was dragged, set the ratio to the new ratio
    if (setRatio)
    {
        editorRatio = position / containerHeight;
    }
}

// Last action
if (external.splmHost_WebSideStartHandShake)
{
    external.splmHost_WebSideStartHandShake();
}
