/*=================================================================================================

                        Copyright (c) 2020 Siemens.
                          All rights reserved


=================================================================================================*/

// When whole webpage is loaded, tell the JournalEditor
document.onload = ready();

// Let the journal editor know that the webpage is ready
function ready()
{
    external.splmHostMethod('notifyWebpageInitialized', '');
}

function notifyFileUpdate()
{
    external.splmHostMethod('notifyFileUpdate', getJournalLines());
}

// Decode the json payload and send it to the ace editor
function loadJournalJSON(jsonPayload) {
    window.currentDocument = jsonPayload.Filepath;
    const source = jsonPayload.FileSource;
    const fileType = jsonPayload.FileType;

    loadJournalDataToAce(source, fileType);
}

// Function to write journal into ace editor
function loadJournalDataToAce(text, fileType)
{
    // Create an object that will be used as a dictionary for the modes
    const modeMapping = {
        '.vb': 'ace/mode/vbscript',
        '.cpp': 'ace/mode/c_cpp',
        '.cxx': 'ace/mode/c_cpp',
        '.java': 'ace/mode/java',
        '.cs': 'ace/mode/csharp',
        '.py': 'ace/mode/python'
    };

    // Set the correct mode for the ace editor's syntax highlighting
    let aceMode = 'ace/mode/vbscript';
    if (modeMapping[fileType])
    {
        aceMode = modeMapping[fileType];
    }

    // Create a new session with the text and mode
    const session = new ace.EditSession(text, aceMode);
    session.setUndoManager(new ace.UndoManager());
    window.editor.setSession(session);

    // Create a new session for the error Console aswell
    const errorSession = new ace.EditSession('');
    window.errorConsole.setSession(errorSession);
}

// Synchronously update the cache. Used when saving during on_cancel.
function updateCache() {
    const lines = getJournalLines();
    return lines;
}

function updateCacheAndNew() {
    const lines = getJournalLines();
    external.splmHostMethod('updateCacheAndNew', lines);
}

function updateCacheAndOpen() {
    const lines = getJournalLines();
    external.splmHostMethod('updateCacheAndOpen', lines);
}


function updateCacheAndSave() {
    const lines = getJournalLines();
    external.splmHostMethod('saveFileFromLines', lines);
}

// return all of the text in the ace editor
function getJournalLines()
{
    const lines = window.editor.getSession().getDocument().getAllLines();
    return lines.join("\n");
}

// Run the journal in NX and load the errors to the syslog
function playJournal()
{
    // Set the cursor to the spinning circle
    document.body.classList.add("scriptRunning");

    // Encode a payload containing the file name and the text lines for NX
    const payload = {
        fileName: window.currentDocument,
        arrayOfLines: window.editor.getSession().getDocument().getAllLines()
    };

    const payloadString = JSON.stringify(payload);

    // Send the payload to NX to run the journal
    if (window.async) {
        external.splmHostMethod('playJournal', payloadString,
            (returnValue) => {
                loadErrorsToConsole(returnValue);
            }
        );
    }
    else {
        const text = external.splmHostMethod('playJournal', payloadString);
        loadErrorsToConsole(text);
    }

    // Set the cursor back to normal
    document.body.classList.remove("scriptRunning");
}

// Load the errors returned from play into the error console
function loadErrorsToConsole(errors)
{
    // Create a new session for the Error Console.
    const session = new ace.EditSession("", 'ace/mode/vbscript');
    session.setUndoManager(new ace.UndoManager());
    window.errorConsole.setSession(session);
    
    // Parse the payload and pull out the errors and lines
    for (let error of Object.values(errors))
    {
        const errorLineNumber = error.Line;
        const errorMessage = error.Error;

        // Construct our line for the Error Console
        const errorLine = "Line " + errorLineNumber + " : " + errorMessage + "\n";

        // Insert our line on a new line
        session.insert(
            {
                row: session.getLength(),
                column: 0
            },
            errorLine
        );
    }
}

// Clear all errors from the console.
function clearConsole() {
    // Create a new session for the Error Console.
    const session = new ace.EditSession("", 'ace/mode/vbscript');
    session.setUndoManager(new ace.UndoManager());
    window.errorConsole.setSession(session);
}

// Creates the JSON payload for play journal
function getTextForPlay() {
    // Set the cursor to the spinning circle
    document.body.classList.add("scriptRunning");

    // Encode a payload containing the file name and the text lines for NX
    const payload = {
        fileName: window.currentDocument,
        arrayOfLines: window.editor.getSession().getDocument().getAllLines()
    };

    const payloadString = JSON.stringify(payload);
    external.splmHostMethod('playFromPayload', payloadString);
}

// Undo over the last operation
function undo() {
    if (!document.execCommand('undo', false, null)) {
        window.editor.getSession().getUndoManager().undo();
    }
}

function find() {  
    if (isEditorActive()) {
        window.editor.commands.commands["find"].exec(window.editor);
    }
    else if (isErrorConsoleActive()) {
        window.errorConsole.commands.commands["find"].exec(window.errorConsole);
    }
    // <yaxp1s> 14-Aug-2020 PR9846809
    // Default to the journal editor
    else {
        window.editor.commands.commands["find"].exec(window.editor);
    }
}

function goToLine() {
    if (isEditorActive()) {
        window.editor.commands.commands["gotoline"].exec(window.editor);
    }
    else if (isErrorConsoleActive()) {
        window.errorConsole.commands.commands["gotoline"].exec(window.errorConsole);
    }
    // <yaxp1s> 14-Aug-2020 PR9846809
    // Default to the journal editor
    else {
        window.editor.commands.commands["gotoline"].exec(window.editor);
    }
}
