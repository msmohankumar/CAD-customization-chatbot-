The installation tool "Tool.zip" has been removed from this location due to the open-source software (OSS) compliance for this tool,
you can still use "Tool.zip" from previous NX release for NX 2212.

If you need the file "Tool.zip", please contact the person below, and we will send out the zip file individually.

Kailiponi, David <david.kailiponi@siemens.com> 
Wen, Jianyong <jianyong.wen@siemens.com> 
