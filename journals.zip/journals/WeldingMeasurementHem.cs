﻿/*==================================================================================================

        This example creates welding measurement of type hem using the section plane method.
 
        This is a journal and is intended to be executed using Tools->Journal->Play.  The part, WeldingExample1.prt,
        must be open before running this journal.  WeldingExample1.prt can be found in the same folder as this journal file.

14-Sep-2011  Computer Programmer        Written
$HISTORY$
==================================================================================================*/

using System;
using NXOpen;

public class NXJournal
{
    public static void Main(string[] args)
    {
        Session theSession = Session.GetSession();
        Part workPart = theSession.Parts.Work;

        NXOpen.Features.Feature nullFeatures_Feature = null;
        NXObject nullNXObject = null;

        // ----------------------------------------------
        //   Measurement Hem: Guide Curve: Section Plane
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder1;
        weldPointBuilder1 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder1.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwMeasurementHem;
        weldPointBuilder1.Location = NXOpen.Weld.WeldPointLocation.SectionPlane;
        weldPointBuilder1.SpacingCalculateMethod = NXOpen.Weld.WeldSpacingCalcMethod.MiddleOfCurve;
        weldPointBuilder1.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder1.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.Top;
        weldPointBuilder1.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;
        weldPointBuilder1.ConnectingOnlyOnePart = true;

        weldPointBuilder1.ClearFaceSets();

        DisplayableObject[] objects3 = new DisplayableObject[1];
        NXOpen.Features.Extrude extrude3 = (NXOpen.Features.Extrude)workPart.Features.FindObject("EXTRUDE(1)");
        Face face3 = (Face)extrude3.FindObject("FACE 160 {(17.3205080756887,-10,-10) EXTRUDE(1)}");
        objects3[0] = face3;
        weldPointBuilder1.SetFaceSet(NXOpen.Weld.WeldFacesetIndex.First, objects3);

        weldPointBuilder1.CommitFaceSets();

        weldPointBuilder1.CommitReferenceSheets(NXOpen.Weld.WeldOverlapStatus.Creation);

        Point3d origin3 = new Point3d(0.0, 0.0, 0.0);
        Vector3d normal3 = new Vector3d(0.0, 0.0, 1.0);
        Plane plane3;
        plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling);

        plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Distance);
        plane3.SetFlip(false);
        plane3.SetReverseSide(false);
        plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One);

        NXObject[] geom3 = new NXObject[1];
        DatumPlane datumPlane3 = (DatumPlane)workPart.Datums.FindObject("DATUM_CSYS(0) XY plane");
        geom3[0] = datumPlane3;
        plane3.SetGeometry(geom3);

        Expression expression3;
        expression3 = plane3.Expression;
        expression3.RightHandSide = "-6.25";

        plane3.Evaluate();

        weldPointBuilder1.SectionPlaneEntity = plane3;

        Section section3b;
        section3b = weldPointBuilder1.CreateSectionPlaneCurves();

        Point3d[] points3;
        weldPointBuilder1.CalculateWeldPoints(out points3);

        NXObject nXObject3;
        nXObject3 = weldPointBuilder1.Commit();

        weldPointBuilder1.Destroy();
    }
    public static int GetUnloadOption(string dummy) { return (int)Session.LibraryUnloadOption.Immediately; }
}
