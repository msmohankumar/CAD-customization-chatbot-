﻿/*==================================================================================================

        This example shows how to set the selection mask for welding objects, select welding objects,
        and assign attributes to the selected welding objects.

14-Sep-2011  Computer Programmer        Written
$HISTORY$
==================================================================================================*/

using System;
using NXOpen;

public class NXJournal
{
    public static void Main(string[] args)
    {
        Session theSession = Session.GetSession();
        UI theUI = UI.GetUI();
        Part workPart = theSession.Parts.Work;

        Selection selectionManager = theUI.SelectionManager;
        NXObject[] objects;
        Selection.MaskTriple[] selectionMask_array = new Selection.MaskTriple[16];
        selectionMask_array[0].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[0].Subtype = 129;
        selectionMask_array[0].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_RESIS_SPOT;
        selectionMask_array[1].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[1].Subtype = 129;
        selectionMask_array[1].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_ARC_SPOT;
        selectionMask_array[2].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[2].Subtype = 129;
        selectionMask_array[2].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_MEC_CLINCH;
        selectionMask_array[3].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[3].Subtype = 129;
        selectionMask_array[3].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_DOLLOP;
        selectionMask_array[4].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[4].Subtype = 129;
        selectionMask_array[4].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_NUT;
        selectionMask_array[5].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[5].Subtype = 129;
        selectionMask_array[5].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_STUD;
        selectionMask_array[6].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[6].Subtype = 129;
        selectionMask_array[6].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_CUSTOM1;
        selectionMask_array[7].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[7].Subtype = 129;
        selectionMask_array[7].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_CUSTOM2;
        selectionMask_array[8].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[8].Subtype = 129;
        selectionMask_array[8].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_CUSTOM3;
        selectionMask_array[9].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[9].Subtype = 129;
        selectionMask_array[9].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_CUSTOM4;
        selectionMask_array[10].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[10].Subtype = 129;
        selectionMask_array[10].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_CUSTOM5;
        selectionMask_array[11].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[11].Subtype = 129;
        selectionMask_array[11].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_GROOVE;
        selectionMask_array[12].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[12].Subtype = 129;
        selectionMask_array[12].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_FILLET;
        selectionMask_array[13].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[13].Subtype = 129;
        selectionMask_array[13].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_USER_DEFINED;
        selectionMask_array[14].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[14].Subtype = 129;
        selectionMask_array[14].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_FILL;
        selectionMask_array[15].Type = NXOpen.UF.UFConstants.UF_feature_type;
        selectionMask_array[15].Subtype = 129;
        selectionMask_array[15].SolidBodySubtype = NXOpen.UF.UFConstants.UF_UI_SEL_FEATURE_WELD_BEAD;

        // Select welding objects
        // All Types AND selectionMask_array
        // selectionManager.SelectObjects("Select objects", "Select Objects", Selection.SelectionScope.AnyInAssembly, Selection.SelectionAction.EnableSpecific, true, true, selectionMask_array, out objects);
        // selectionMask_array
        selectionManager.SelectObjects("Select objects", "Select Objects", Selection.SelectionScope.AnyInAssembly, Selection.SelectionAction.ClearAndEnableSpecific, true, true, selectionMask_array, out objects);

        // Customer attributes and values
        String[] titles = {"Customer Attr 1", "Customer Attr 2", "Customer Attr 3"};
        String[] values = { "Customer Value 1", "Customer Value 2", "Customer Value 3" };

        // Set attributes
        for (int idx = 0; idx < objects.Length; idx++)
        {
            for (int jdx = 0; jdx < titles.Length; jdx++)
            {
                objects[idx].SetAttribute(titles[jdx], values[jdx], Update.Option.Now);
            }
        }
    }

    public static int GetUnloadOption(string dummy) { return (int)Session.LibraryUnloadOption.Immediately; }
}
