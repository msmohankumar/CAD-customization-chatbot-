﻿/*==================================================================================================

        This example creates welding measurements of type hole using various methods.
 
        This is a journal and is intended to be executed using Tools->Journal->Play.  The part, WeldingExample1.prt,
        must be open before running this journal.  WeldingExample1.prt can be found in the same folder as this journal file.

14-Sep-2011  Computer Programmer        Written
$HISTORY$
==================================================================================================*/

using System;
using NXOpen;

public class NXJournal
{
    public static void Main(string[] args)
    {
        Session theSession = Session.GetSession();
        Part workPart = theSession.Parts.Work;

        NXOpen.Features.Feature nullFeatures_Feature = null;
        NXObject nullNXObject = null;

        // ----------------------------------------------
        //   Measurement Hole: Points
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder1;
        weldPointBuilder1 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder1.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwMeasurementHole;
        weldPointBuilder1.PointMethod = NXOpen.Weld.WeldPointMethod.Single;
        weldPointBuilder1.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder1.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.None;
        weldPointBuilder1.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;
        weldPointBuilder1.ConnectingOnlyOnePart = true;

        weldPointBuilder1.ClearFaceSets();

        DisplayableObject[] objects1 = new DisplayableObject[1];
        NXOpen.Features.Extrude extrude1 = (NXOpen.Features.Extrude)workPart.Features.FindObject("EXTRUDE(1)");
        Face face1 = (Face)extrude1.FindObject("FACE 150 {(17.3205080756888,-10,10) EXTRUDE(1)}");
        objects1[0] = face1;
        weldPointBuilder1.SetFaceSet(NXOpen.Weld.WeldFacesetIndex.First, objects1);

        weldPointBuilder1.CommitFaceSets();

        weldPointBuilder1.CommitReferenceSheets(NXOpen.Weld.WeldOverlapStatus.Creation);

        Point3d pointCoord1 = new Point3d(15.772771529522, -16.6240560956994, 12.6807583346921);
        weldPointBuilder1.CreateSingleWeldPoint(pointCoord1);

        NXObject nXObject1;
        nXObject1 = weldPointBuilder1.Commit();

        weldPointBuilder1.Destroy();

        // ----------------------------------------------
        //   Measurement Hole: From Existing Points
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder2;
        weldPointBuilder2 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder2.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwMeasurementHole;
        weldPointBuilder2.PointMethod = NXOpen.Weld.WeldPointMethod.FromPoints;
        weldPointBuilder2.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder2.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.None;
        weldPointBuilder2.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;

        TaggedObject[] refs2 = new TaggedObject[1];
        NXOpen.Features.PointFeature pointFeature2 = (NXOpen.Features.PointFeature)workPart.Features.FindObject("POINT(3)");
        Point point2 = (Point)pointFeature2.FindObject("POINT 1");
        refs2[0] = point2;
        weldPointBuilder2.SetMirrorTranslateReferenceObjects(refs2);

        NXObject nXObject2;
        nXObject2 = weldPointBuilder2.Commit();

        weldPointBuilder2.Destroy();

        // ----------------------------------------------
        //   Measurement Hole: Mirror
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder3;
        weldPointBuilder3 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder3.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwMeasurementHole;
        weldPointBuilder3.PointMethod = NXOpen.Weld.WeldPointMethod.Mirror;
        weldPointBuilder3.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder3.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.None;
        weldPointBuilder3.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;

        TaggedObject[] refs3 = new TaggedObject[1];
        NXOpen.Features.Feature feature3 = (NXOpen.Features.Feature)nXObject1;
        NXOpen.Features.Feature[] parents3 = feature3.GetParents();
        Point point3 = (Point)parents3[0].FindObject("POINT 1");
        refs3[0] = point3;
        weldPointBuilder3.SetMirrorTranslateReferenceObjects(refs3);

        Point3d origin3 = new Point3d(0.0, 0.0, 0.0);
        Vector3d normal3 = new Vector3d(0.0, 0.0, 1.0);
        Plane plane3;
        plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling);

        plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Distance);
        plane3.SetFlip(false);
        plane3.SetReverseSide(false);
        plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One);

        NXObject[] geom3 = new NXObject[1];
        DatumPlane datumPlane3 = (DatumPlane)workPart.Datums.FindObject("DATUM_CSYS(0) XZ plane");
        geom3[0] = datumPlane3;
        plane3.SetGeometry(geom3);

        Expression expression3;
        expression3 = plane3.Expression;
        expression3.RightHandSide = "6.25";

        plane3.Evaluate();

        weldPointBuilder3.MirrorPlane = plane3;

        NXObject nXObject3;
        nXObject3 = weldPointBuilder3.Commit();

        weldPointBuilder3.Destroy();

        // ----------------------------------------------
        //   Measurement Hole: Translate
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder4;
        weldPointBuilder4 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder4.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwMeasurementHole;
        weldPointBuilder4.PointMethod = NXOpen.Weld.WeldPointMethod.Translate;
        weldPointBuilder4.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder4.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.None;
        weldPointBuilder4.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;

        TaggedObject[] refs4 = new TaggedObject[1];
        NXOpen.Features.Feature feature4 = (NXOpen.Features.Feature)nXObject1;
        NXOpen.Features.Feature[] parents4 = feature4.GetParents();
        Point point4 = (Point)parents4[0].FindObject("POINT 1");
        refs4[0] = point4;
        weldPointBuilder4.SetMirrorTranslateReferenceObjects(refs4);

        NXOpen.Features.Extrude extrude4 = (NXOpen.Features.Extrude)workPart.Features.FindObject("EXTRUDE(1)");
        Face face4 = (Face)extrude4.FindObject("FACE 150 {(17.3205080756888,-10,10) EXTRUDE(1)}");

        Xform xform4;
        xform4 = workPart.Xforms.CreateXform(face4, NXOpen.SmartObject.UpdateOption.AfterModeling);
        CartesianCoordinateSystem cartesianCoordinateSystem4;
        cartesianCoordinateSystem4 = workPart.CoordinateSystems.CreateCoordinateSystem(xform4, NXOpen.SmartObject.UpdateOption.AfterModeling);
        weldPointBuilder4.TranslateCsys = cartesianCoordinateSystem4;
        weldPointBuilder4.TranslateXDistance = "10.000000";
        weldPointBuilder4.TranslateYDistance = "10.000000";
        weldPointBuilder4.TranslateZDistance = "10.000000";

        NXObject nXObject4;
        nXObject4 = weldPointBuilder4.Commit();

        weldPointBuilder4.Destroy();
    }
    public static int GetUnloadOption(string dummy) { return (int)Session.LibraryUnloadOption.Immediately; }
}
