'      Sample vb file that can be customized and executed from a button in NX.
'      This vb will set the Assemblies Preference Display as Entire Part to True. 
'
'      This preference will effect the Mouse Button "Make Work Part". When "Display as Entire Part"
'      preference is true, and Make Work Part is used, the reference set will be set to Entire Part.
'
' TEXT ENCLOSED within delete markers will be REMOVED
'==================================================================================================

Imports System
Imports NXOpen

Module NXJournal
Sub Main (ByVal args() As String) 

Dim theSession As NXOpen.Session = NXOpen.Session.GetSession()

' ----------------------------------------------
'   Menu: Preferences->Assemblies...
' ----------------------------------------------

theSession.Preferences.Assemblies.WorkPartDisplayAsEntirePart = True

' ----------------------------------------------
'   Menu: Tools->Journal->Stop Recording
' ----------------------------------------------

End Sub
End Module
