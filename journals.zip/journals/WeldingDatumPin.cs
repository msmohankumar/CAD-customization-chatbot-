﻿/*==================================================================================================

        This example creates body in white datums of type pin using various methods.
 
        This is a journal and is intended to be executed using Tools->Journal->Play.  The part, WeldingExample1.prt,
        must be open before running this journal.  WeldingExample1.prt can be found in the same folder as this journal file.

14-Sep-2011  Computer Programmer        Written
$HISTORY$
==================================================================================================*/

using System;
using NXOpen;

public class NXJournal
{
    public static void Main(string[] args)
    {
        Session theSession = Session.GetSession();
        Part workPart = theSession.Parts.Work;

        NXOpen.Features.Feature nullFeatures_Feature = null;
        NXObject nullNXObject = null;

        // ----------------------------------------------
        //   Datum Pin: Points
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder1;
        weldPointBuilder1 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder1.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwDatumPin;
        weldPointBuilder1.PointMethod = NXOpen.Weld.WeldPointMethod.Single;
        weldPointBuilder1.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder1.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.Top;
        weldPointBuilder1.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;
        weldPointBuilder1.ConnectingOnlyOnePart = true;

        weldPointBuilder1.ClearFaceSets();

        DisplayableObject[] objects1 = new DisplayableObject[1];
        NXOpen.Features.Extrude extrude1 = (NXOpen.Features.Extrude)workPart.Features.FindObject("EXTRUDE(1)");
        Face face1 = (Face)extrude1.FindObject("FACE 150 {(17.3205080756888,-10,10) EXTRUDE(1)}");
        objects1[0] = face1;
        weldPointBuilder1.SetFaceSet(NXOpen.Weld.WeldFacesetIndex.First, objects1);

        weldPointBuilder1.CommitFaceSets();

        weldPointBuilder1.CommitReferenceSheets(NXOpen.Weld.WeldOverlapStatus.Creation);

        Point3d pointCoord1 = new Point3d(15.772771529522, -16.6240560956994, 12.6807583346921);
        weldPointBuilder1.CreateSingleWeldPoint(pointCoord1);

        NXObject nXObject1;
        nXObject1 = weldPointBuilder1.Commit();

        weldPointBuilder1.Destroy();

        // ----------------------------------------------
        //   Datum Pin: Guide Curve: Offset From Edge
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder2;
        weldPointBuilder2 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder2.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwDatumPin;
        weldPointBuilder2.Location = NXOpen.Weld.WeldPointLocation.AlongGuideEdge;
        weldPointBuilder2.SpacingCalculateMethod = NXOpen.Weld.WeldSpacingCalcMethod.MiddleOfCurve;
        weldPointBuilder2.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder2.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.Top;
        weldPointBuilder2.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;
        weldPointBuilder2.ConnectingOnlyOnePart = true;

        weldPointBuilder2.ClearFaceSets();

        DisplayableObject[] objects2 = new DisplayableObject[1];
        NXOpen.Features.Extrude extrude2 = (NXOpen.Features.Extrude)workPart.Features.FindObject("EXTRUDE(1)");
        Face face2 = (Face)extrude2.FindObject("FACE 140 {(0,-10,20) EXTRUDE(1)}");
        objects2[0] = face2;
        weldPointBuilder2.SetFaceSet(NXOpen.Weld.WeldFacesetIndex.First, objects2);

        weldPointBuilder2.CommitFaceSets();

        weldPointBuilder2.CommitReferenceSheets(NXOpen.Weld.WeldOverlapStatus.Creation);

        Edge[] edges2 = new Edge[1];
        NXOpen.Features.Feature feature2 = (NXOpen.Features.Feature)workPart.Features.FindObject("WELD_SHEET(10)");
        Edge edge2 = (Edge)feature2.FindObject("EDGE * 1 * 1 1 {(-11.5470053837925,-20,20)(0,-20,20)(11.5470053837925,-20,20) WELD_SHEET(10)}");
        edges2[0] = edge2;
        EdgeDumbRule edgeDumbRule2;
        edgeDumbRule2 = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges2);

        SelectionIntentRule[] rules2 = new SelectionIntentRule[1];
        rules2[0] = edgeDumbRule2;

        Section section2;
        section2 = workPart.Sections.CreateSection();

        section2.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves);
        section2.AllowSelfIntersection(false);

        Point3d helpPoint2 = new Point3d(1.48986483651115, -20.0, 20.0);
        section2.AddToSection(rules2, edge2, nullNXObject, nullNXObject, helpPoint2, NXOpen.Section.Mode.Create, false);

        weldPointBuilder2.SetFirstSection(section2);

        Section section2a;
        section2a = weldPointBuilder2.CreateOffsetCurve();

        weldPointBuilder2.CommitSection(section2a);

        Point3d[] points2;
        weldPointBuilder2.CalculateWeldPoints(out points2);

        NXObject nXObject2;
        nXObject2 = weldPointBuilder2.Commit();

        weldPointBuilder2.Destroy();

        // ----------------------------------------------
        //   Datum Pin: Guide Curve: Section Plane
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder3;
        weldPointBuilder3 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder3.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwDatumPin;
        weldPointBuilder3.Location = NXOpen.Weld.WeldPointLocation.SectionPlane;
        weldPointBuilder3.SpacingCalculateMethod = NXOpen.Weld.WeldSpacingCalcMethod.MiddleOfCurve;
        weldPointBuilder3.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder3.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.Top;
        weldPointBuilder3.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;
        weldPointBuilder3.ConnectingOnlyOnePart = true;

        weldPointBuilder3.ClearFaceSets();

        DisplayableObject[] objects3 = new DisplayableObject[1];
        NXOpen.Features.Extrude extrude3 = (NXOpen.Features.Extrude)workPart.Features.FindObject("EXTRUDE(1)");
        Face face3 = (Face)extrude3.FindObject("FACE 160 {(17.3205080756887,-10,-10) EXTRUDE(1)}");
        objects3[0] = face3;
        weldPointBuilder3.SetFaceSet(NXOpen.Weld.WeldFacesetIndex.First, objects3);

        weldPointBuilder3.CommitFaceSets();

        weldPointBuilder3.CommitReferenceSheets(NXOpen.Weld.WeldOverlapStatus.Creation);

        Point3d origin3 = new Point3d(0.0, 0.0, 0.0);
        Vector3d normal3 = new Vector3d(0.0, 0.0, 1.0);
        Plane plane3;
        plane3 = workPart.Planes.CreatePlane(origin3, normal3, NXOpen.SmartObject.UpdateOption.WithinModeling);

        plane3.SetMethod(NXOpen.PlaneTypes.MethodType.Distance);
        plane3.SetFlip(false);
        plane3.SetReverseSide(false);
        plane3.SetAlternate(NXOpen.PlaneTypes.AlternateType.One);

        NXObject[] geom3 = new NXObject[1];
        DatumPlane datumPlane3 = (DatumPlane)workPart.Datums.FindObject("DATUM_CSYS(0) XY plane");
        geom3[0] = datumPlane3;
        plane3.SetGeometry(geom3);

        Expression expression3;
        expression3 = plane3.Expression;
        expression3.RightHandSide = "-6.25";

        plane3.Evaluate();

        weldPointBuilder3.SectionPlaneEntity = plane3;

        Section section3b;
        section3b = weldPointBuilder3.CreateSectionPlaneCurves();

        Point3d[] points3;
        weldPointBuilder3.CalculateWeldPoints(out points3);

        NXObject nXObject3;
        nXObject3 = weldPointBuilder3.Commit();

        weldPointBuilder3.Destroy();

        // ----------------------------------------------
        //   Datum Pin: Guide Curve: Centerline
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder4;
        weldPointBuilder4 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder4.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwDatumPin;
        weldPointBuilder4.Location = NXOpen.Weld.WeldPointLocation.AlongCenterLine;
        weldPointBuilder4.SpacingCalculateMethod = NXOpen.Weld.WeldSpacingCalcMethod.MiddleOfCurve;
        weldPointBuilder4.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder4.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.Top;
        weldPointBuilder4.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;
        weldPointBuilder4.ConnectingOnlyOnePart = true;

        weldPointBuilder4.ClearFaceSets();

        DisplayableObject[] objects4 = new DisplayableObject[1];
        NXOpen.Features.Extrude extrude4 = (NXOpen.Features.Extrude)workPart.Features.FindObject("EXTRUDE(1)");
        Face face4 = (Face)extrude4.FindObject("FACE 190 {(-17.3205080756888,-10,10) EXTRUDE(1)}");
        objects4[0] = face4;
        weldPointBuilder4.SetFaceSet(NXOpen.Weld.WeldFacesetIndex.First, objects4);

        weldPointBuilder4.CommitFaceSets();

        weldPointBuilder4.CommitReferenceSheets(NXOpen.Weld.WeldOverlapStatus.Creation);

        Edge[] edges4a = new Edge[1];
        NXOpen.Features.Feature feature4a = (NXOpen.Features.Feature)workPart.Features.FindObject("WELD_SHEET(16)");
        Edge edge4a = (Edge)feature4a.FindObject("EDGE * 1 * 1 3 {(-11.5470053837925,-20,20)(-11.5470053837925,-10,20)(-11.5470053837925,0,20) WELD_SHEET(16)}");
        edges4a[0] = edge4a;
        EdgeDumbRule edgeDumbRule4a;
        edgeDumbRule4a = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges4a);

        SelectionIntentRule[] rules4a = new SelectionIntentRule[1];
        rules4a[0] = edgeDumbRule4a;

        Section section4a;
        section4a = workPart.Sections.CreateSection();

        section4a.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves);
        section4a.AllowSelfIntersection(false);

        Point3d helpPoint4a = new Point3d(-11.5470053837925, -11.8014972155485, 20.0);
        section4a.AddToSection(rules4a, edge4a, nullNXObject, nullNXObject, helpPoint4a, NXOpen.Section.Mode.Create, false);

        weldPointBuilder4.SetFirstSection(section4a);

        Edge[] edges4b = new Edge[1];
        NXOpen.Features.Feature feature4b = (NXOpen.Features.Feature)workPart.Features.FindObject("WELD_SHEET(16)");
        Edge edge4b = (Edge)feature4b.FindObject("EDGE * 1 * 1 1 {(-23.094010767585,-20,0.0000000000001)(-17.3205080756888,-20,10)(-11.5470053837925,-20,20) WELD_SHEET(16)}");
        edges4b[0] = edge4b;
        EdgeDumbRule edgeDumbRule4b;
        edgeDumbRule4b = workPart.ScRuleFactory.CreateRuleEdgeDumb(edges4b);

        SelectionIntentRule[] rules4b = new SelectionIntentRule[1];
        rules4b[0] = edgeDumbRule4b;

        Section section4b;
        section4b = workPart.Sections.CreateSection();

        section4b.SetAllowedEntityTypes(NXOpen.Section.AllowTypes.OnlyCurves);
        section4b.AllowSelfIntersection(false);

        Point3d helpPoint4b = new Point3d(-17.7578898154085, -20.0, 9.24243260450259);
        section4b.AddToSection(rules4b, edge4b, nullNXObject, nullNXObject, helpPoint4b, NXOpen.Section.Mode.Create, false);

        weldPointBuilder4.SetSecondSection(section4b);

        Section section4c;
        section4c = weldPointBuilder4.CreateCenterLine();

        weldPointBuilder4.CommitSection(section4c);

        Point3d[] points4;
        weldPointBuilder4.CalculateWeldPoints(out points4);

        NXObject nXObject4;
        nXObject4 = weldPointBuilder4.Commit();

        weldPointBuilder4.Destroy();

        // ----------------------------------------------
        //   Datum Pin: From Existing Points
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder5;
        weldPointBuilder5 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder5.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwDatumPin;
        weldPointBuilder5.PointMethod = NXOpen.Weld.WeldPointMethod.FromPoints;
        weldPointBuilder5.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder5.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.None;
        weldPointBuilder5.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;

        TaggedObject[] refs5 = new TaggedObject[1];
        NXOpen.Features.PointFeature pointFeature5 = (NXOpen.Features.PointFeature)workPart.Features.FindObject("POINT(3)");
        Point point5 = (Point)pointFeature5.FindObject("POINT 1");
        refs5[0] = point5;
        weldPointBuilder5.SetMirrorTranslateReferenceObjects(refs5);

        NXObject nXObject5;
        nXObject5 = weldPointBuilder5.Commit();

        weldPointBuilder5.Destroy();

        // ----------------------------------------------
        //   Datum Pin: Mirror
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder6;
        weldPointBuilder6 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder6.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwDatumPin;
        weldPointBuilder6.PointMethod = NXOpen.Weld.WeldPointMethod.Mirror;
        weldPointBuilder6.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder6.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.None;
        weldPointBuilder6.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;

        TaggedObject[] refs6 = new TaggedObject[1];
        NXOpen.Features.Feature feature6 = (NXOpen.Features.Feature)nXObject4;
        NXOpen.Features.Feature[] parents6 = feature6.GetParents();
        Point point6 = (Point)parents6[0].FindObject("POINT 1");
        refs6[0] = point6;
        weldPointBuilder6.SetMirrorTranslateReferenceObjects(refs6);

        Point3d origin6 = new Point3d(0.0, 0.0, 0.0);
        Vector3d normal6 = new Vector3d(0.0, 0.0, 1.0);
        Plane plane6;
        plane6 = workPart.Planes.CreatePlane(origin6, normal6, NXOpen.SmartObject.UpdateOption.WithinModeling);

        plane6.SetMethod(NXOpen.PlaneTypes.MethodType.Distance);
        plane6.SetFlip(false);
        plane6.SetReverseSide(false);
        plane6.SetAlternate(NXOpen.PlaneTypes.AlternateType.One);

        NXObject[] geom6 = new NXObject[1];
        DatumPlane datumPlane6 = (DatumPlane)workPart.Datums.FindObject("DATUM_CSYS(0) YZ plane");
        geom6[0] = datumPlane6;
        plane6.SetGeometry(geom6);

        Expression expression6;
        expression6 = plane6.Expression;
        expression6.RightHandSide = "0";

        plane6.Evaluate();

        weldPointBuilder6.MirrorPlane = plane6;

        NXObject nXObject6;
        nXObject6 = weldPointBuilder6.Commit();

        weldPointBuilder6.Destroy();

        // ----------------------------------------------
        //   Datum Pin: Translate
        // ----------------------------------------------

        NXOpen.Weld.WeldPointBuilder weldPointBuilder7;
        weldPointBuilder7 = workPart.Features.WeldManager.CreateWeldPointBuilder(nullFeatures_Feature);

        weldPointBuilder7.WeldType = NXOpen.Weld.WeldFeatureSetType.BiwDatumPin;
        weldPointBuilder7.PointMethod = NXOpen.Weld.WeldPointMethod.Translate;
        weldPointBuilder7.ProjectionMethod = NXOpen.Weld.WeldProjectionMethod.None;
        weldPointBuilder7.ReferenceSheetType = NXOpen.Weld.WeldPointReferenceSheetType.None;
        weldPointBuilder7.SolidType = NXOpen.Weld.WeldCustom.SolidDefault;

        TaggedObject[] refs7 = new TaggedObject[1];
        NXOpen.Features.Feature feature7 = (NXOpen.Features.Feature)nXObject4;
        NXOpen.Features.Feature[] parents7 = feature7.GetParents();
        Point point7 = (Point)parents7[0].FindObject("POINT 1");
        refs7[0] = point7;
        weldPointBuilder7.SetMirrorTranslateReferenceObjects(refs7);

        NXOpen.Features.Extrude extrude7 = (NXOpen.Features.Extrude)workPart.Features.FindObject("EXTRUDE(1)");
        Face face7 = (Face)extrude7.FindObject("FACE 190 {(-17.3205080756888,-10,10) EXTRUDE(1)}");

        Xform xform7;
        xform7 = workPart.Xforms.CreateXform(face7, NXOpen.SmartObject.UpdateOption.AfterModeling);
        CartesianCoordinateSystem cartesianCoordinateSystem7;
        cartesianCoordinateSystem7 = workPart.CoordinateSystems.CreateCoordinateSystem(xform7, NXOpen.SmartObject.UpdateOption.AfterModeling);
        weldPointBuilder7.TranslateCsys = cartesianCoordinateSystem7;
        weldPointBuilder7.TranslateXDistance = "10.000000";
        weldPointBuilder7.TranslateYDistance = "10.000000";
        weldPointBuilder7.TranslateZDistance = "10.000000";

        NXObject nXObject7;
        nXObject7 = weldPointBuilder7.Commit();

        weldPointBuilder7.Destroy();
    }
    public static int GetUnloadOption(string dummy) { return (int)Session.LibraryUnloadOption.Immediately; }
}
