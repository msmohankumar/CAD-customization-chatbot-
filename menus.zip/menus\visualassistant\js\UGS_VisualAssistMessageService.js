﻿/*HEAD UGS_VisualAssistMessageService js */
/*==================================================================================================

        Copyright (c) 2018 Siemens Product Lifecycle Management Software Inc.
                     Unpublished - All rights reserved

====================================================================================================
File description:


====================================================================================================
Date         Name                    Description of Change
20-Mar-2017  Satyajit Majumder       Written
12-Apr-2018  Satyajit Majumder       Added method ASK_DIALOG_FOCUS
26-Jul-2019  Mahesh Jagtap           ARCH1899003: Added support for Autotest( Added method onLoadModel)
$HISTORY$
==================================================================================================*/

'use strict';

UGS.VisualAssistMessageService = function () {
    UGS.MessageService.call(this,
		"com.siemens.nx.visualassistdata", "V1.0",
		"com.siemens.nx.visualassisthosting", "1.0");

    var OnFocusIn = function (id) { };
    var OnFocusOut = function (id) { };
	var onLoadModel = function (id) { };
};

UGS.VisualAssistMessageService.prototype = Object.create(UGS.MessageService.prototype);
UGS.VisualAssistMessageService.prototype.constructor = UGS.VisualAssistMessageService;

if (UGS.VisualAssistMessageService.prototype.ProcessEvent !== 'undefined') {
    UGS.VisualAssistMessageService.prototype.ProcessEvent = function (parsedEventData) {

        if (parsedEventData.messageType == "Focus_In") {
            this.OnFocusIn(parsedEventData.value);
        }
        else if (parsedEventData.messageType == "Focus_Out") {
            this.OnFocusOut(parsedEventData.value);
        }
		else if (parsedEventData.messageType == "Load_Model") {
            this.onLoadModel(parsedEventData.value);
        }
    };
}

UGS.VisualAssistMessageService.prototype.AskDialogFocus = function () {

    // This operation name ASK_DIALOG_FOCUS to get visual assist first message.
    // We do not need to pass any stringIdentifier.

    var eventValue = "ASK_DIALOG_FOCUS";
    var liveHelpTag = " ";
    var inputParams = { stringIdentifier: liveHelpTag, event: eventValue };
    var inputMessage = JSON.stringify(inputParams);
    this.PerformOperation(inputMessage);
}
