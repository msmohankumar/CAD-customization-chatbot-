﻿/*HEAD UGS_LiveHelp js */
/*==================================================================================================

        Copyright (c) 2018 Siemens Product Lifecycle Management Software Inc.
                     Unpublished - All rights reserved

====================================================================================================
File description:


====================================================================================================
Date         Name                    Description of Change
20-Mar-2018  Satyajit Majumder       Written
12-Apr-2018  Satyajit Majumder       Added method AskDialogFocus
27-Apr-2018  Satyajit Majumder       Fixed Issue
29-Apr-2018  Mike Brown              Various fixes and adjustments to behavior
20-May-2018  Mike Brown              Many fixes and code cleanup
22-Jun-2018  Mike Brown              Improve Mouse wheel, turn off non-PMI selection
19-Jul-2018  Zara Mann               Small change in scroll thumbnail movements
17-Aug-2018  Mike Brown              PR#9219556: mouse wheel zoom inconsistent w/customer defaults. 
10-Feb-2019  Mike Brown              Update to PLM Vis Web 1.5.0
29-Apr-2019  Satyajit Majumder       PR 9437834 focus will not change unless Specify block is picked in NX dialog 
26-Jul-2019  Mahesh Jagtap           ARCH1899003: Added support for Autotest
27-Aug-2019  Mahesh Jagtap           PR9555994 Do not load the default model in LoadContext if we want to explicitly load a particular model.
$HISTORY$
==================================================================================================*/

'use strict';
	
// ***************  Live Help Tags *************** //
	
// Constants for LiveHelp tagging
	
// Live Help Tag
const LIVE_HELP = "LIVE_HELP";

	
// ***************  Live Help State Data *************** //
	
// The currently available Live Help data being displayed.
var liveHelpContent = null;
// Currently selected Context index
var selectedContext = -1;
// Currently selected Model index
var selectedModel   = -1;

// Selection currently being shown
var currentSelectionId = "";
	
// View OrientationInfo stored when switching between models
var homeViewOrientationInfo = null;
var restoreViewOrientationInfo = null;
	
// Mapping of liveHelp tagged properties to psIDs
var PropertyToIDMap = new UGS.MultiMap;
var IDToPropertyMap = new UGS.MultiMap;

// load state
var modelPMILoaded = false;
var modelPropertiesLoaded = false;
var modelRootVisible = false;
var allModelPSVisible = false;
var allModelPMIVisible = false;

// <Mike Brown> 12-Feb-2019
// PLM Vis Web does not support highlighting of
// PMI.  Instead we change the color ourselves
// and track those we have changes to revert them
// back when done highlighting.
var highlightedPMI = [];

// ***************  Localization  *************** //

// current locale setting
var currentLocale = "";
var LOCALIZE = {};

function UpdateLocale(locale)
{
	var data;
	$.getJSON("localization/" + locale + ".json")
	
		.done(function (data, textStatus, jqXHR) 
			{ 
				/* success */ 
				LOCALIZE = data;
				LoadContent(liveHelpContent);
			})
		.fail(function (jqXHR, textStatus, errorThrown) 
			{ 
				/* error */ 
				UpdateLocale("en_US");
			}); 
};

// <Mike Brown> 02-Feb-2019
// Add global error handling as fallback
// window.onerror = function(msg, url, line, col, error) {
	
	// console.log("VISUAL ASSISTANT ERROR: " + msg + " : " + line);
    // //window.location = "error.html";
	
	// // Suppress alerts, not sure if this gets executed after
	// // setting window.location or not.
	// return true;
// }
	
// ***************  PLM Vis Web Setup *************** //
	
	
// <Mike Brown> 20-May-2018
// Use two seperate viewers to reduce flickering
// by loading new model in background.
var params, controlManager, viewerManager, pmiManager, propertiesManager;

params = {
	name: "LiveHelp",
	host: document.getElementById('plmviswebHost'),
	width: document.getElementById('content').offsetWidth + 'px',
	height: document.getElementById('content').offsetHeight + 'px',
	webworkerCount: 0, // Resolve loading from UNC paths.  Issue filed with PLM Vis Web
	root: null
}

controlManager = new PLMVisWeb.Control(params);
viewerManager = controlManager.getExtensionManager(PLMVisWeb.Viewer);
pmiManager = viewerManager.addExtension(PLMVisWeb.PMI);
propertiesManager = viewerManager.addExtension(PLMVisWeb.Properties);
// <Mike Brown> 29-Apr-2018
// Measurement Manager not currently used but 
// supports pre-selection highlighting.
//var measurementManager = viewerManager.addExtension(PLMVisWeb.Measurement);
	
SetupViewer(viewerManager, pmiManager);

// Set a handler for when the window resizes
window.onresize = ResizeContent;
// Perform initial resize of PLM Vis Web content
ResizeContent();

// <Mike Brown> 20-May-2018
// Set initial PLMVisWeb Configurations
function SetupViewer(viewerMgr, pmiMgr)
{
	viewerMgr.setCameraMode(PLMVisWeb.CameraMode.ORTHOGRAPHIC);
	viewerMgr.setRenderMode(PLMVisWeb.EdgeType.Shaded);
	viewerMgr.setDefaultBackgroundRGBA(1.0,1.0,1.0,1.0);
		
	// <Mike Brown> 10-Feb-2019
	// Version 1.5.0 supports Picking vs Selection.
	// Called by PLM Vis Web in response to direct selection
	// on an entity in the scene.  With setPickingOnly set
	// to true, this does not actually do selection, but only
	// notifies of the event and allows the client to decide
	// how to respond.
	viewerManager.setPickingEnabled(true);
	viewerManager.setPickingMode(PLMVisWeb.PickingMode.FREE);
	// Do not select on pick, allow client to decide.
	viewerManager.setPickOnly(true);
	viewerManager.registerPickingEvent(OnPickingEvent);
	
	// Highlight on rollover
	viewerManager.setMouseHighlightEnabled(false);
	
	// <Mike Brown> 10-Feb-2019
	// Disable WCS
	var wcs = viewerManager.getWCS();
	if (wcs != undefined)
		wcs.visible = false;

	viewerMgr.setSelectionMaterial(0xF6A049, 0xF6A049, 0x000000, 0xFFFFFF, 100, 1);
	viewerMgr.setHighlightingMaterial(0xF6A049, 0xF6A049, 0x000000, 0xFFFFFF, 100, 1);
	pmiMgr.setPmiSelectionMaterial(0xF6A049, 0.5);
	pmiMgr.autoTextFlipping = true;
	
	// <Mike Brown> 11-Feb-2019
	// Increase the tolerance of picking lines
	// such as PMI.  Default value is 4.
	PLMVisWeb.Utilities.setRaycasterLinePrecision = 6;
}

function ResizeContent(e) 
{
	// If PLM Vis Web's content does not fill the window
	// than the following help size it correctly.
	// Currently not needed. 
		
	var content = document.getElementById('content');
		
	var contentTop = content.offsetTop;
		
	var contentHeight = window.innerHeight - contentTop;
	
	// <Mike Brown> 10-Feb-2019
	// Don't allow negative size.
	if (contentHeight < 0)
		contentHeight = 0;
		
	if (controlManager) {
		controlManager.setSize(window.innerWidth, contentHeight);
	}
}
	
	 
	 
// **********  Host Interop Messaging Services Setup *********** //
	
// Create the Live Help Message Services.
// Coordinates communication to and from LiveHelpWebService
// through HostInterop.
var liveHelpMessageService = new UGS.LiveHelpMessageService(); 
	
// Set a callback for when content is recieved from LiveHelp.
liveHelpMessageService.OnContentReceived = function(contentData)
{
	liveHelpContent = contentData;
	if (contentData.locale != currentLocale)
	{
		UpdateLocale(contentData.locale);
	}
	else
	{
		LoadContent(contentData);
	}
}
	
// Create the Visual Assist Message Services.
// Coordinates communication to and from VisualAssistWebService
// through HostInterop.
var visualAssistMessageService = new UGS.VisualAssistMessageService(); 

// Set a handler for VisualAssist FocusIn events.
visualAssistMessageService.OnFocusIn = function(id)
{
	// Clear any current selection
	if ( params.root ) {
		viewerManager.setSelectionByPsId( params.root, false, true );
		viewerManager.selectNone();
		//pmiManager.selectNone();
	}

	currentSelectionId = id;
	SetSelectionByName(id, true);
}
	
// Set a handler for VisualAssist FocusOut events.
visualAssistMessageService.OnFocusOut = function(id)
{
	if (currentSelectionId == id)
	{		
		// Clear any current selection
		if ( params.root ) {
			viewerManager.setSelectionByPsId( params.root, false, true );
			viewerManager.selectNone();
			pmiManager.selectNone();
		}
		currentSelectionId = "";
	}
	//SetSelectionByName(id, false);
}

// <Mahesh Jagtap> 26-Jul-2019 ARCH1899003
// Change to particular context/model

visualAssistMessageService.onLoadModel = function(id)
{
	// We receive the context and model from NX in a comma separated format context_number,model_number
	var fields = id.split(',');
	LoadContext(fields[0], false);
	LoadModel(fields[1]);
}

var Init = function() 
{
	// Satyajit - Need to registered web service in this function 
	// before calling RequestLiveHelpContent
	try
	{
		
		if (globalhostedInfo !== undefined)
		{
			globalhostedInfo.webServices.push(liveHelpMessageService);
			globalhostedInfo.webServices.push(visualAssistMessageService);
		}
		else
		{
		    console.log("VISUAL ASSISTANT: globalhostedInfo undefined");
		}
	}
	catch(err)
	{
	}
			
	function keypressEvent(e) 
	{
		var keynum = 0;

		if(window.event)
		{ // IE                 
			keynum = e.keyCode;
		}
		else
		{
			if(e.which)
			{ // Netscape/Firefox/Opera                  
				keynum = e.which;
			}
		}
			
		if (keynum == 36 /* Home */)
		{
			SetHomeViewOrientation();
			
			e.preventDefault();
			e.stopPropagation();
		}
	}
			
	// <Mike Brown> 29-Apr-2018
	// No supported context menu entires have been 
	// defined.  for now just remove this to 
	// prevent the user from seeing the back/forward
	// options.
	// Disable context menu
	document.addEventListener('contextmenu', event => event.preventDefault());

    // Key press events
	document.addEventListener("keyup", keypressEvent);
		
	liveHelpMessageService.RequestLiveHelpContent();
		
}


// <Mike Brown> 20-May-2018
// Override the globalhostedInfo Init function to be notified
// when setup has completed.  This is needed because
// the HostInterop setup is now async and will notify
// when complete.
try
{
	if (globalhostedInfo !== undefined)
	{
		globalhostedInfo.Init = Init; 
	}
}
catch(err)
{
	if(UGS.isSandbox())
	{
		Init();
	}
}

// All PLMVisWeb content has finished loading
function CheckContentLoad()
{
	if (modelPropertiesLoaded && modelPMILoaded && modelRootVisible && 
        allModelPMIVisible && allModelPSVisible)
	{		
		
		// <Mike Brown> 23-May-2018
		// Turn on rendering now that load complete.
		viewerManager.setAutoDraw(true);
		
		viewerManager.setEdgesVisibilityByPsId(params.root, true);
		
		if (restoreViewOrientationInfo == null) {
		
			viewerManager.fitToModel();
			//viewerManager.fitToVisible();
		}
		
		restoreViewOrientationInfo = null;

		pmiManager.reorientText(true);
		SetNXLighting();
		
		// <Mike Brown> 29-Apr-2018
		// Wait until PMI and Properties have
		// finished loading or the initial
		// LiveHelp event supplying focus
		// will not find it's target.
		visualAssistMessageService.AskDialogFocus();
	}
}


// ***************  User Interface  *************** //

function BindButtonEvents(buttons)
{
	//*****//

	buttons.hover(
	function () 
	{
		SetHovered($(this));
	},
	function () 
	{
		SetNormal($(this));
	});     

	buttons.mousedown(
	function () 
	{
		SetPressed($(this));
	});

	buttons.mouseup(
	function () 
	{
		SetHovered($(this));
	});
		
}

function SetNormal(e)
{
	e.removeClass("hotState pressedState").addClass("normalState");
}

function SetHovered(e)
{
	e.removeClass("normalState pressedState").addClass("hotState");
}

function SetPressed(e)
{
	e.removeClass("hotState normalState").addClass("pressedState");
}

function SetSelected(e, set)
{
	if (set)
	{
		e.addClass("selectedState");
	}
	else
	{
		e.removeClass("selectedState");
	}
}

// Allow the thumbnails to scroll when dragged
var scrollClicked = false, scrollClickX;
$("#contextThumbnails").on({
	'mousemove': function(e) {
		scrollClicked && updateScrollPos(e);
		// <Zara Mann> 19-Jul-2018
		// Allow propagation to allow rotation of 
		// graphics when mouse moves above thumbnails
		//e.stopPropagation();
	},
	'mousedown': function(e) {
		scrollClicked = true;
		scrollClickX = e.screenX;
		e.stopPropagation();
	},
	'mouseup': function(e) {
		scrollClicked = false;
		//$('html').css('cursor', 'auto');
		//e.stopPropagation();
	},
	'mousewheel': function(e) {
		e.stopPropagation();
	},
	'mouseleave': function(e) {
		scrollClicked = false;
	},
	'click': function(e) {
		e.stopPropagation();
	},
	'dragstart': function() {
		// prevent image drag and drop
		return false;
	}
});

// Update the scroll position
var updateScrollPos = function(e) 
{
	var delta = scrollClickX - e.screenX;
	if (delta != 0)
	{
		var thumbnails = $("#contextThumbnails").eq(0);
		//$('html').css('cursor', 'e-resize');
		thumbnails.scrollLeft(thumbnails.scrollLeft() + delta);
		scrollClickX = e.screenX;
	}
}
	

// ***************  Content Loading  *************** //

function LoadModel(index)
{
	// <Mike Brown> 23-May-2018
	// Turn off rendering to reduce flicker.
	viewerManager.setAutoDraw(false);
	
	if (selectedContext === -1)
	{
		// LOADING: UGS.debugMessage("Error: LoadModel called with no selected Context");
		return;
	}
	
	// <Mike Brown> 23-May-2018
	// PR#9167883: Can no longer reset by clicking button.
	// Decided this was a useful if accidental feature.
	//if (selectedModel == index)
	//	return;
		
    // Cleanup map
	PropertyToIDMap = new UGS.MultiMap();
	IDToPropertyMap = new UGS.MultiMap();
	
	// Clear list of PMI highlights
	highlightedPMI = [];
	
	// Reset
	modelPMILoaded = false;
	modelPropertiesLoaded = false;
	allModelPSVisible = false;
	allModelPMIVisible = false;
	
	selectedModel = index;
		
	var buttons = $("#divDescModel").find(".button");
	var buttonsLen = buttons.length;
		
	SetSelected(buttons, false);
	for(var i = 0; i < buttonsLen; i++)
	{
		if (buttons.eq(i).attr("data-index") == index)
		{
			SetSelected(buttons.eq(i), true);
		};
	}
		
	var imgpath = liveHelpContent.contexts[selectedContext].models[index].path;
	
	
	viewerManager.open(imgpath, OnFileOpenComplete);
	
    // <Mahesh Jagtap> 26-Jul-2019 ARCH1899003: Send context/model change to NX for Custom Macro
    // Custom Message : Load_Model Context=1,Model=1  

	var eventValue = "CUSTOM_RECORD";
	var messageType = "Load_Model";
	var context_model = "Context=" + selectedContext + "," + "Model=" + index;
	var message = messageType + " " + context_model;
	var inputParams = { stringIdentifier: message, event: eventValue };
	var inputMessage = JSON.stringify(inputParams);
	visualAssistMessageService.PerformOperation(inputMessage);
}

function LoadContext(index, load_active = true)
{
	// <Mike Brown> 23-May-2018
	// PR#9167883: Can no longer reset by clicking button.
	// Decided this was a useful if accidental feature.
	//if (selectedContext == index)
	//	return;
	
	// Set the current selection
	selectedContext = index;
	// Clear current model
	selectedModel = -1;
		
	var thumbnails = $(".thumbnail");
	var thumbnailsLen = thumbnails.length;
		
	SetSelected(thumbnails, false);
	for(var i=0;i<thumbnailsLen;i++)
	{
		if (thumbnails.eq(i).attr("data-index") == index)
		{
			SetSelected(thumbnails.eq(i), true);
		};
	}
		
	// Update controls per selection
		
	var contexts = liveHelpContent.contexts;
	$( "#divDesc" ).find(".blockLabel").html("<b>" + LOCALIZE["DESCRIPTION"] + " : </b>" + contexts[index].description);
		
	var len = contexts[index].models.length;
	var models = contexts[index].models;
		
	models.sort(function(a, b) {
		return parseFloat(a.index) - parseFloat(b.index);
	});
		
	var buttonPrefab = $(".button").eq(0);  
	var buttonContainer = $("#divDescModel").find(".blockOptionContainer").eq(0);  
	buttonContainer.empty(); 
		
	var clone;	
	var activeIndex = 0;
	
	for(var i=0;i<len;i++)
	{
		clone = buttonPrefab.clone();  
				
		clone.attr("data-index", models[i].index);
		clone.find("span").eq(0).html(models[i].label);
		clone.appendTo(buttonContainer);
		
		if (models[i].active == "true")
			activeIndex = i;
	}
	
	if (contexts[index].reflect.length)
	{
		// <Mike Brown> 3-Jun-2018
		// apply Reflect immediately on thumbnail activate.
		var eventValue = "SET_DIALOG_FAVORITE";
		var inputParams = { stringIdentifier: contexts[index].reflect, event: eventValue };

		var inputMessage = JSON.stringify(inputParams);
		visualAssistMessageService.PerformOperation(inputMessage);
	}
		
	var buttons = $(".button");
	BindButtonEvents(buttons);	
	buttons.click(function ()
		{
			// When swapping between models, store the
			// current camera orientation to restore
			// after model loaded.
			restoreViewOrientationInfo = viewerManager.getCameraOrientationInfo();
			LoadModel($(this).attr("data-index"));   
		});
	SetNormal(buttons);

    // <Mahesh Jagtap> 03-Sep-2019 PR9555994
    // While replaying, we have a replay model number that needs to be loaded. 
	// So, we are not required to load the default model.
    // Also, when we try to load both, the default model as well as the replay model, they interfere with each other and the replay model is not always loaded.
    // So we are not laoding the default model while replaying.
	if(load_active)
	{	
	    LoadModel(activeIndex);
	}
}

// new code for json object
function LoadContent(contentData)
{
	LoadConfig(contentData.config);

	// Clear current context
	selectedContext = -1;
	// Clear current model
	selectedModel = -1;
	
	var contexts = liveHelpContent.contexts;
	contexts.sort(function(a, b) {
		return parseFloat(a.index) - parseFloat(b.index);
	});
		
	var thumbnailPrefab = $(".contexts").eq(0);  
	var thumbnailContainer = $("#contextThumbnails");  
	thumbnailContainer.empty(); 
		
	var clone;
	var activeIndex = 0;
		
	var len = contexts.length;
	for(var i = 0; i < len; i++)
	{
		clone = thumbnailPrefab.clone(); 
			
		var img = clone.find("img").eq(0);		
		img.attr("data-index", contexts[i].index);
		img.attr("src", contexts[i].preview);
			
		clone.appendTo(thumbnailContainer);
		
		if (contexts[i].active == "true")
			activeIndex = i;
	}
		

	var thumbnails = $(".thumbnail");
	BindButtonEvents(thumbnails);	
	thumbnails.click(function ()
		{           
			LoadContext($(this).attr("data-index"));   
		});
	SetNormal(thumbnails);
		
	LoadContext(activeIndex);
		
	ResizeContent();
}

// not yet implemented
function LoadConfig(configData)
{
	var zoomSpeed = 1.5;
	if (configData.reverseScroll == "true")
		zoomSpeed = -1.5;
	
	viewerManager.overrideMouseNavigationControls(NX.NavigationControls,
	    {rotateSpeed: 3.0, zoomSpeed: zoomSpeed, panSpeed: 0.12});
}


// ***********  Live Help to PLM Vis Web  ************ //

function GetLiveHelpTags(psId)
{
	var tags = [];
	
	// Get the properties
	var prop = propertiesManager.getProperties(psId, false); 

	if (prop !== undefined && prop["properties"] != undefined)
	{
		// Check for LIVE_HELP:: properties indicating a mapping
		// to a dialog element.  There may be more than one 
		// property per psID.  As there are multiple ways that
		// properties keys can appear (private-"LIVE_HELP::", 
		// PMI-"LIVE_HELP_Display", Multi value with PMI-"LIVE_HELP[1]_Display")
		// it is cleaner just to look for anything that starts 
		// with the LIVE_HELP identifier.
		for (var key in prop.properties) {
			if (key.startsWith(LIVE_HELP))
				tags.push(prop.properties[key]);
		}
	}

	return tags;
}
	
// Reset view to home position
function SetHomeViewOrientation()
{
	if (homeViewOrientationInfo != null)
	{
		// There is previously stored camera orientation
		// info, restore it instead of default.
		viewerManager.setCameraOrientationInfo(homeViewOrientationInfo);
	}
	else
	{
		SetViewOrientation();
	}
}
	
function SetViewOrientation()
{
	var liveHelpView = null;
	var trimetricView = null;
		
	// <Mike Brown> 24-Feb-2019
	// We are now just setting the Trimetric view directly
	// and ignoring the ModelView from NX.  THe ModelView
	// was giving too many problems, such as not existing
	// when no PMI, excluded parts, etc.  Keeping
	// code around for a while until validated approach.
		
	// Get the available views in the PLM structure.
	if (false) //viewerManager.modelHasPmi(params.root))
	{
		var info = pmiManager.getModelViewsStructureInfo();
		if (info != null && info !== undefined)
		{
			for (var i = 0; i < info.children.length; i++) 
			{ 
				var child = info.children[i];
				for (var j = 0; j < child.children.length; j++) 
				{
					// Look for the trimetric view by default
					var view = child.children[j];
					if (view != undefined && 
						view.name != undefined)
					{
						// Support custom LIVE_HELP view name.
						if (view.name == "LIVE_HELP")
						{
							liveHelpView = view;
						}
						// Default apply the trimetric view.
						else if (view.name == "_Trimetric_")
						{
							trimetricView = view;
						}
					}
				}	 
			}	 
		}
	}
		
	// Apply the view
	if (liveHelpView != null)
	{
		pmiManager.setModelViewActive(liveHelpView.psId, true);
	}
	// Default apply the trimetric view.
	else if (trimetricView != null)
	{
		// <Mike Brown> 18-Feb-2019
		// Issue with curves not being shown.
		// HACK WARNING: For some reason NX seems to be 
		// outputting wireframe objects with flags that indicate
		// they should be excluded in the model view.  
		// The below code is extracted from the PLM Vis Web
		// code that sets the model view.  It blindly deletes
		// all excluded part data from the model view in order
		// to prevent it from being hidden when we apply the view.
		var mv;
		if ( pmiManager._pmiObject.userData.modelViewMap !== undefined && trimetricView.psId !== null && trimetricView.psId !== undefined ) {
			mv = pmiManager._pmiObject.userData.modelViewMap[ trimetricView.psId.toString() ];
			
			if ( mv.excPartIds ) {
				delete mv.excPartIds;
			}
		}
		
		pmiManager.setModelViewActive(trimetricView.psId, true);				
	}
	else
	{		
		// Need to add path for when no Model View is available
		// Manually set to trimetric.
		viewerManager.setCameraToStandardView(PLMVisWeb.StandardViewType.TRIMETRIC);
	}
	
	if (restoreViewOrientationInfo != null)
	{
		// There is previously stored camera orientation
		// info, restore it instead of default.
		viewerManager.setCameraOrientationInfo(restoreViewOrientationInfo);
	}
	else
	{
		// Ensure all geometry and PMI is visible.
		viewerManager.fitToModel();
		//viewerManager.fitToVisible();
	}
	
	// Store the home orientation for reset.
	homeViewOrientationInfo = viewerManager.getCameraOrientationInfo();
}

function SetNXLighting()
{
	// <Mike Brown> 29-Apr-2018
	// Test hack for nx lighting effects
	// More is needed from PLM Vis Web
	// to fully support.  Currently resets
    // on any selection and requires refresh.
	var dLights = {
			hexColor: 0x808080, // directional light color
			intensity: 1.0 // 0.0-1.0 intensity value
	};
	tweakDirectionalLights( dLights );
		 
	var ambient = {
			hexColor: 0x999999, // ambient light color
			intensity: 0.8 // 0.0-1.0 intensity value
	};
	tweakAmbientLight( ambient );
		 
	var specular = {
			hexColor: 0x333333, // specular material color
			intensity: 1.0, // 0.0-1.0 intensity value
			shininess: 5 // shininess material value
	};
	tweakSpecular( specular );
	
	viewerManager.draw();
}

// <Mike Brown> 12-Feb-2019
// We do not have a picking event for highlight
// the way we do on mouse click.  In order
// to do our own filtering for highlighting
// we listen to mouse movement and query what
// is under the cursor.  

// Track the previous found id.
var preselectionPsId = "";
function OnCanvasMouseMove(event)
{
	// Ask for the thing under the cursor.
	var newTarget = viewerManager.getPsIdAtViewCoordinate(event.offsetX,event.offsetY);
	
	// If something was found.
	if (newTarget)
	{		
		// If the target has changed since the last mouse movement
		if (newTarget.psId != preselectionPsId)
		{
			// clear any previous highlighting
			ClearPMIHighlighting();

			// Update tracked ID for next movement
			preselectionPsId = newTarget.psId;
			
			// We don't want this to flicker for small movements on/off target.
			//  Set timeout where the mouse needs to remain on the same target.
			setTimeout(function (event)
				{
					// If the target hasn't changed
					if (newTarget.psId == preselectionPsId)
					{
						// Check if the target is something we care about
						var liveHelpTags = IDToPropertyMap.get(preselectionPsId);
						if (Array.isArray(liveHelpTags) && liveHelpTags.length)
						{
							// Get all IDs associated with the tag.
							// This allows highlighting everything associated with
							// the thing under the cursor.
							var selectionIds = PropertyToIDMap.get(liveHelpTags[0]);
							
							for ( var i = 0; i < selectionIds.length; i++) 
							{
								if (pmiManager.isPmiObject(selectionIds[i]))
								{
									// Track color overrides to revert back later
									highlightedPMI.push(selectionIds[i]);
									pmiManager.setPmiColorByPsId(selectionIds[i], 0xC8362B, 5.0);
								}
								else
								{
									// <Mike Brown> 12-Feb-2019
									// Not supporting highlight on non-PMI right now.  This gets complicated
									// as we also use the highlight for PMI associations.  If we set it
									// for preselection then we must make sure to put it back correctly
									// when we clear so it doesn't impact selected PMI associations.
									//viewerManager.setHighlightByPsId( selectionIds[i], true, false);
								}								
							}
						}
					}
				}, 
			100);
		}
	}
	else
	{
		// Clear PMI color override when target changes to nothing.
		if (preselectionPsId != "")
		{
			ClearPMIHighlighting();
		}
		
		preselectionPsId = "";		
	}
}

function ClearPMIHighlighting()
{
	var newHighlights = [];
	
	// clear highlights
	//viewerManager.setHighlightByPsIds( [], true, true);
	for ( var i = 0; i < highlightedPMI.length; i++) 
	{
		if (pmiManager.getSelectionByPsId(highlightedPMI[i]))
		{
			// Don't black out PMI if it is selected.  We don'tag
			// have a function to simply clear the override color.
			// So we need to set the color to the selected color.
			pmiManager.setPmiColorByPsId(highlightedPMI[i], 0xF6A049, 5.0);
			
			// We need to track that we have overridden this color so
			// it can be cleaned up when selection occurs.
			newHighlights.push(highlightedPMI[i]);
		}
		else
		{
			// Set back to black
			pmiManager.setPmiColorByPsId(highlightedPMI[i], 0x000000, 5.0);
		}			
	}
	
	// Update list of PMI color overrides.
	highlightedPMI = newHighlights;
}

// Called by PLM Vis Web in response to direct selection
// on an entity in the scene.  With setPickingOnly set
// to true, this does not actually do selection, but only
// notifies of the event and allows the client to decide
// how to respond.
function OnPickingEvent(evt)
{
		viewerManager.setEdgesVisibilityByPsId(params.root, true);
	
	var psID = evt.psId;
	
	// Get the Live Help tags
	var liveHelpTags = IDToPropertyMap.get(psID);
	if (Array.isArray(liveHelpTags) && liveHelpTags.length)
	{
		// Can only use one value if multiple.
		var liveHelpTag = liveHelpTags[0];
	
		var isSelected = false;
		if (pmiManager.isPmiObject(psID))
		{
			isSelected = pmiManager.getSelectionByPsId(psID);
		}
		else 
		{
			isSelected = viewerManager.getSelectionByPsId(psID);
		}
		// SELECTION: UGS.debugMessage("Selection Event for Live Help tag : " + liveHelpTag + " = " + isSelected);
			
		SetSelectionByName(liveHelpTag, !isSelected);

		// Sending to NX, only send selection, not deselection
		if (!isSelected) 
		{
			var eventValue = "SET_DIALOG_FOCUS";
			var inputParams = { stringIdentifier: liveHelpTag, event: eventValue };

			var inputMessage = JSON.stringify(inputParams)
			visualAssistMessageService.PerformOperation(inputMessage);
		}
	
	}

	//SetNXLighting();
}
// This method removes last string after "->" including "->" 
// Input SID = UGS::ModlSurfaceUI::SectionSurfaceEx->spineVector->constructor 
// Output UGS::ModlSurfaceUI::SectionSurfaceEx->spineVector
function GetParentIdentifier(name) 
{ 
	var n = name.lastIndexOf("->"); 
	return name.substr(0, n); 
} 


function SetSelectionByName(name, value)
{		
	// SELECTION: UGS.debugMessage("SetSelectionByName : " + name + " " + value);
	try
	{
		// Lookup the IDs associated with the named property
		var psIds = undefined; 
		var tmpName = name; 
		// Lookup the IDs associated with the named property. 
		// recurse up the name identifier until a match is found. 
		while ((psIds = PropertyToIDMap.get(tmpName)) == undefined) 
		{ 
			tmpName = GetParentIdentifier(tmpName); 
			if (tmpName == "") 
			break; 
		} 

		// TODO: there is currently an issue setting multiple
		// things selected at once programmatically.  Setting
		// one seems to unselect another.
		if (psIds !== undefined)
		{
			// SELECTION: UGS.debugMessage("SetSelectionByName IDs : " + psIds);
		    // <Mahesh Jagtap> 26-Jul-2016 
		    // This is for testing framework. We have found the component in Visual Assistant. Send a confirmation back to NX

			var eventValue = "NOTIFY_SELECTION";
			var inputParams = { stringIdentifier: name, event: eventValue };
			var inputMessage = JSON.stringify(inputParams);
			visualAssistMessageService.PerformOperation(inputMessage);
			
			if (value) {
				
				// Clear any current selection
				if ( params.root ) {
					viewerManager.setSelectionByPsId( params.root, false, true );
					viewerManager.selectNone();
				}
			}
				
			var preservePMISelection = false;
			for ( var i = 0; i < psIds.length; i++) 
			{
				if (pmiManager.isPmiObject(psIds[i]))
				{
					if (value != pmiManager.getSelectionByPsId(psIds[i]))
					{
						// SELECTION: UGS.debugMessage("pmiManager.setSelectionByPsId('" + psIds[i] + "', " + value + ", true);");
						pmiManager.setSelectionByPsId(psIds[i], value, true, preservePMISelection);
						preservePMISelection = true;
					}
				}
				else
				{
					if (value != viewerManager.getSelectionByPsId(psIds[i]))
					{
						// SELECTION: UGS.debugMessage("viewerManager.setSelectionByPsId('" + psIds[i] + "', " + value + ", false);");
						
						viewerManager.setSelectionByPsId(psIds[i], value, false);
					}
				}
			}
		}
	}
	catch (err)
	{
		// SELECTION: UGS.debugMessage("Error caught in SetSelectionByName : " + err);
	}
	
	ClearPMIHighlighting();
	SetNXLighting();		
}

function OnFileOpenComplete(success, rootID) 
{	
	// LOADING: UGS.debugMessage("OnFileOpenComplete");
	params.root = rootID;
	
	// Set the root visible
	// <Mike Brown> 30-Apr-2018
	// call onFinishedContentLoad after setting the visibility
	// Attempting to select anything that is not yet visible will
	// currently fail until this issue is resolved in the tools.
	viewerManager.setVisibilityByPsId(params.root, true, function()
		{
			modelRootVisible = true;
			CheckContentLoad();
		});
	
		
	// Load PMI
	if (viewerManager.modelHasPmi(params.root)) 
	{
		pmiManager.loadPmiData(params.root, OnLoadPMI);
	}
	else
	{
		allModelPMIVisible = true;
		OnLoadPMI();
	}	
		
	// <Mike Brown> 11-Feb-2019
	// The canvas requires some setup and error handlers
	// This needs to be done post creation by PLMVisWeb.
	PostCanvasCreation();
}

function OnLoadPMI()
{
	modelPMILoaded = true;
	
	// Set the view orientation now that it
	// has been loaded from PMI data.
	SetViewOrientation();
		
	// Need to load properties post-PMI load
	propertiesManager.loadProperties(params.root, OnLoadProperties);
}

function OnLoadProperties()
{
	modelPropertiesLoaded = true;
	
	// LOADING: UGS.debugMessage("onLoadPmiProperties");
	
	try
	{
		// traverse the product structure to map Live Help tags
		var psInfo = viewerManager.getProductStructureInfo();
		MapLiveHelpToProductStructure(psInfo);
		
		// Set all PMI Visible
		SetProductStructureVisibility(psInfo, true, function()
		{
			allModelPSVisible = true;
			CheckContentLoad();
		});
	}
	catch (err)
	{
		// LOADING: UGS.debugMessage("Error catch : mapLiveHelpToProductStructure Error : " + err);
	}
		
	if (viewerManager.modelHasPmi(params.root)) 
	{
		try
		{
			// traverse the PMI structure to map Live Help tags
			var pmiInfo = pmiManager.getPmiStructureInfo();
			MapLiveHelpToPMI(pmiInfo);
			
			// Set all PMI Visible
			SetPMIVisibility(pmiInfo, true, function()
			{
				allModelPMIVisible = true;
				CheckContentLoad();
			});
		}
		catch (err)
		{
			// LOADING: UGS.debugMessage("Error catch : MapLiveHelpToPMI Error : " + err);
		}
	}
		
	// Properties is the last piece of content that loads.
	// Now we can notify content load finished.
	CheckContentLoad();
}

var initCanvasEvents = false; // Only setup once per session.
function PostCanvasCreation()
{
	if (initCanvasEvents == false)
	{
		// <Mike Brown> 10-Feb-2019
		// Add some error output for issues with content
		var canvas = document.getElementsByTagName('canvas')[0];
		if (canvas.addEventListener) 
		{
			// <Mike Brown> 11-Feb-2019
			// Disable attempt at prehighlighting control for now.
			canvas.addEventListener( 'mousemove', OnCanvasMouseMove, false );
			
			canvas.addEventListener("webglcontextcreationerror", function(event) 
			{
			    console.log("VISUAL ASSISTANT: Context Creation Error");
			    //window.location = "error.html";
			}, false);
		}
		var glContext = viewerManager.getWebGLContext();
		if (glContext) 
		{
			if (canvas.addEventListener) 
			{
				canvas.addEventListener("webglcontextlost", function(event) 
				{
					console.log("VISUAL ASSISTANT: Context Lost");
					event.preventDefault();
						//window.location = "error.html";
				}, false);
				canvas.addEventListener("webglcontextrestored", function(event) 
				{			  
					console.log("VISUAL ASSISTANT: Context Restored");
						//window.location = "error.html";
				}, false);
			}
		} 
		else 
		{
			if (!window.WebGLRenderingContext) 
			{
			   console.log("VISUAL ASSISTANT: !window.WebGLRenderingContext");
			   //window.location = "error.html";
			}
		}
		
		initCanvasEvents = true;
	}
}

// Recursive function to map Live Help tags to Product Structure IDs
function MapLiveHelpToProductStructure(psInfo)
{
	if (psInfo == null)
		return;
		
	if (psInfo.psId != undefined)
	{		
		// Get the Live Help tags
		var liveHelpTags = GetLiveHelpTags(psInfo.psId); 
		var numTags = liveHelpTags.length;
		for (var i = 0; i < numTags; i++) 
		{
			if (liveHelpTags[i] != undefined) 
			{
				// LOADING: UGS.debugMessage("Live Help Property for id : " + psInfo.psId + " = " + liveHelpTags[i]);
				PropertyToIDMap.set(liveHelpTags[i], psInfo.psId);
				IDToPropertyMap.set(psInfo.psId, liveHelpTags[i]);
			}
		}
	}
		
	// recurse through children
	if (psInfo.children)
	{
		for (var i = 0; i < psInfo.children.length; i++) 
		{ 
			MapLiveHelpToProductStructure(psInfo.children[i]);
		}	 
	}
}

// Recursive function to map Live Help tags to PMI IDs
function MapLiveHelpToPMI(pmiInfo)
{
	if (pmiInfo == null)
		return;
		
	if (pmiInfo.psId != undefined)
	{			
		// Get the Live Help tags
		var liveHelpTags = GetLiveHelpTags(pmiInfo.psId); 
		
		var numTags = liveHelpTags.length;
		for (var i = 0; i < numTags; i++) 
		{
			if (liveHelpTags[i] != undefined) 
			{
				// Store the mapping
				// SELECTION: UGS.debugMessage("Live Help Property for id : " + pmiInfo.psId + " = " + liveHelpTags[i]);
				PropertyToIDMap.set(liveHelpTags[i], pmiInfo.psId);
				IDToPropertyMap.set(pmiInfo.psId, liveHelpTags[i]);
				
				// <Mike Brown> 11-Feb-2019
				// Also add all associated bodies under the same tag.
				// This allows them to be selected by the user directly.
				// Turning this off as it ends up selecting entires
				// bodies when only edges or faces are associated.
				// Further investigation needed.
				
				// traverse the product structure to map Live Help tags
				 // var pmiStructureInfo = pmiManager.getPmiStructureInfo(pmiInfo.psId, [PLMVisWeb.AttributeFlag.PMI_ASSOCIATIONS], 0);
				 // if (pmiStructureInfo.xtIds.length != 0)
				 // {
					 // for (var j = 0; j < pmiStructureInfo.xtIds.length; j++) 
					 // {
						 // var xtId = pmiStructureInfo.xtIds[j];
						
						  // var index = xtId.indexOf("|");
						  // if(index > 0)
						   // xtId = xtId.slice(0, index);  						
						
						 // // Store the mapping
						 // PropertyToIDMap.set(liveHelpTags[i], xtId);
						 // IDToPropertyMap.set(xtId, liveHelpTags[i]);
					 // }
				 // }
			}
		}
	}
		
	// recurse through children
	if (pmiInfo.children)
	{
		for (var i = 0; i < pmiInfo.children.length; i++) 
		{ 
			MapLiveHelpToPMI(pmiInfo.children[i]);
		}	 
	}
}

// Recursive function to map Live Help tags to PMI IDs
function SetProductStructureVisibility(psInfo, visible, callback)
{	
	var children = [];
	
	// function to gather all children
	var getChildren = function (info, array) {		
			// recurse through children
			array.push(info.psId);
			if (info.children)
			{
				for (var i = 0; i < info.children.length; i++) 
				{ 
					getChildren(info.children[i], array);
				}	 
			}
		};
	
	// call to get children
	getChildren(psInfo, children);
	
	// closure variables
	var numChildren = children.length,
		childCount = 0;
	// function to track when all children have been made visible
	var done_fn = function () {
		if ( ++childCount === numChildren ) {
			callback();
		}
	};

	// Set all children visible
	for (var i = 0; i < children.length; i++) 
	{ 
		viewerManager.setVisibilityByPsId(children[i], visible, done_fn);
	}	 
}

// Recursive function to map Live Help tags to PMI IDs
function SetPMIVisibility(pmiInfo, visible, callback)
{
	var children = [];
	
	// function to gather all children
	var getChildren = function (info, array) {		
			// recurse through children
			array.push(info.psId);
			if (info.children)
			{
				for (var i = 0; i < info.children.length; i++) 
				{ 
					getChildren(info.children[i], array);
				}	 
			}
		};
	
	// call to get children
	getChildren(pmiInfo, children);
	
	// closure variables
	var numChildren = children.length,
		childCount = 0;
	// function to track when all children have been made visible
	var done_fn = function () {
		if ( ++childCount === numChildren ) {
			callback();
		}
	};

	// Set all children visible
	for (var i = 0; i < children.length; i++) 
	{ 
		pmiManager.setVisibilityByPsId(children[i], visible, done_fn);
	}
	
}
