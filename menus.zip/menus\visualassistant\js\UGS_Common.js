﻿/*HEAD UGS_Common js */
/*==================================================================================================

        Copyright (c) 2018 Siemens Product Lifecycle Management Software Inc.
                     Unpublished - All rights reserved

====================================================================================================
File description:


====================================================================================================
Date         Name                    Description of Change
20-Mar-2018  Satyajit Majumder       Written
29-Apr-2018  Mike brown              Add sandbox token
$HISTORY$
==================================================================================================*/

'use strict';	

var UGS = {
	
	debug : undefined,
	test : undefined,
	
	isDebug : function()
	{
		if (this.debug === undefined)
		{
			this.debug = this.getUrlParameter("debug") == "true";
		}
		
		return true; //this.debug;
	},
	
	isSandbox : function()
	{
		if (this.test === undefined)
		{
			this.test = this.getUrlParameter("test") == "true";
		}
		
		return this.test;
	},
	
	// MultiMap
	MultiMap : function()
	{
	   var content = {};

	   this.set = function(key, value)
	   {
		   if (content[key] === undefined) content[key] = [];
		   content[key].push(value);
	   },
	 
	   this.get = function(key)
	   {
		   return content[key];
	   }
	},
	
	getUrlParameter : function (sParam) {
		var sPageURL = decodeURIComponent(window.location.search.substring(1)),
			sURLVariables = sPageURL.split('&'),
			sParameterName,
			i;

		for (i = 0; i < sURLVariables.length; i++) {
			sParameterName = sURLVariables[i].split('=');

			if (sParameterName[0] === sParam) {
				return sParameterName[1] === undefined ? true : sParameterName[1];
			}
		}
	},
	
	// Create a simple common location for debug messages.
	// We can expand later as needed.  Can simply turn all on 
	// or off by removing the return.
	debugMessage : function(message, token)
	{
		if (UGS.isDebug())
			console.log(message);
	}
}