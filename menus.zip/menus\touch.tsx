<?xml version="1.0" encoding="UTF-8"?>
<!--

-->


<NX_TOUCHSCHEME>
  <UIElement class="BasicTouchSheet" name="defaults">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="5" cy="5"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="pushButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="flatPushButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="pulldownButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="dialogNavigationButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="8" cy="8"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="radioButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="toggleButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="spinBox">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="5" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="splitButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="splitDropdownButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="5" cy="5"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="splitButtonPopupItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="tabItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="8" cy="8"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="editBox">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="listBoxItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="treeListItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="treeListHeaderItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="treeListExpandCollapseButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="gridViewItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="gridViewItemHeader">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="gridViewHorizontalGroupItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="gridViewVerticalGroupItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="gridViewExpandCollapseButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="listViewItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="listViewExpandCollapseButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="tileListExpandCollapseButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="coverFlowExpandCollapseButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="thumbnailListHeader">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="toolbarButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="6" cy="6"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="toolbarHorizontalSplitDropdownButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="4" cy="5"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="toolbarEditBox">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="toolbarComboBox">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="toolbarComboBoxDropdownButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="menuItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="8" cy="8"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="resourceBarTabItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="8" cy="6"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="floatControlBarCloseButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="6"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="dockedControlBarHorizontalCaption">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="dockedControlBarVerticalCaption">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="ribbonTabItem">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="8" cy="6"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="galleryOpenButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="colorPicker">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="colorPaletteWell">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="8" cy="8"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="chevronFavoriteButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="3" cy="3"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="level1GroupBlockHeader">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="level1GroupBlockHeaderButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="level2GroupBlockHeader">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="level2GroupBlockHeaderButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="navigatorSecondaryDialogHorizontalSplitter">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="3" cy="3"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="navigatorSecondaryDialogVerticalSplitter">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="3" cy="3"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="horizontalDockSplitter">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="3" cy="3"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="verticalDockSplitter">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="3" cy="3"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="gadgetHeader">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="7" cy="7"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="quickAccessToolbarButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="6" cy="6"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="quickAccessToolbarEditBox">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="6" cy="6"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="ribbonSystemBarButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="6" cy="6"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="ribbonSystemBarEditBox">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="6" cy="6"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="statusBarButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="4" cy="4"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="popupPadFrameCaption">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="5" cy="5"/>
    </TouchSheet>
  </UIElement>
  <UIElement class="BasicTouchSheet" name="popupPadToolButton">
    <TouchSheet class="BasicTouchSheet">
      <minSize cx="10" cy="10"/>
    </TouchSheet>
  </UIElement>
</NX_TOUCHSCHEME>

