﻿/*HEAD UGS_LiveHelpMessageService js */
/*==================================================================================================

        Copyright (c) 2018 Siemens Product Lifecycle Management Software Inc.
                     Unpublished - All rights reserved

====================================================================================================
File description:


====================================================================================================
Date         Name                    Description of Change
20-Mar-2018  Satyajit Majumder       Written
29-Apr-2018  Mike Brown              Update testbed content
25-Jun-2018  Mike Brown              Update testbed content again
10-Feb-2019  Mike Brown              Add sample of config data
$HISTORY$
==================================================================================================*/

UGS.LiveHelpMessageService = function() 
{ 
	UGS.MessageService.call(this, 
		"com.siemens.nx.livehelpdata", "V1.0", 
		"com.siemens.nx.livehelphosting", "1.0");
			
    var OnContentReceived = function(contentData){};
};

UGS.LiveHelpMessageService.prototype = Object.create(UGS.MessageService.prototype); 
UGS.LiveHelpMessageService.prototype.constructor = UGS.LiveHelpMessageService; 

UGS.LiveHelpMessageService.prototype.ProcessEvent = function(parsedEventData) 
{ 
	this.OnContentReceived(parsedEventData);
};

UGS.LiveHelpMessageService.prototype.RequestLiveHelpContent = function()
{
	if(UGS.isSandbox())
	{        
		// Load debug data
		this.loadTestbed();
	}
	else
	{
						
	    // This operation name Request_Content to get LiveHelpData.
	    // We do not need to pass any stringIdentifier.

		var eventValue = "Request_Content";
		var inputParams = { stringIdentifier: "", event:eventValue };
		var inputMessage = JSON.stringify(inputParams)
		this.PerformOperation(inputMessage);
	}
}

// Replaces the data load from the host when running in debug
UGS.LiveHelpMessageService.prototype.loadTestbed = function()
{
	var parsedEventData = {"dialogID": "UGS::ModlAeroUI::Step", "locale": "en_US", "contexts": [{"preview": "ModlAeroUI_Step/AeroStepThickMiddlev2.png", "title": "Aero_Step_Jog_Cutout", "description": "A Step feature using type Thick with location type Middle about a datum plane.", "index": "0", "active": "", "reflect": "UGS::ModlAeroUI::Step::0::Visual Assistant - Thick Middle", "models": [{"label": "Input", "path": "ModlAeroUI_Step/AeroStepThickMiddle_Input", "index": "0", "active": ""}, {"label": "Output", "path": "ModlAeroUI_Step/AeroStepThickMiddle_Output", "index": "1", "active": "true"}]}, {"preview": "ModlAeroUI_Step/AeroStepJogEndToFace.png", "title": "Aero Step - Jog End to Face", "description": "A Step feature using type Thick with location type Middle about a datum plane.", "index": "1", "active": "", "reflect": "UGS::ModlAeroUI::Step::0::Visual Assistant - Jog End to Face", "models": [{"label": "Input", "path": "ModlAeroUI_Step/AeroStepJogEndtoFace_Input", "index": "0", "active": ""}, {"label": "Output", "path": "ModlAeroUI_Step/AeroStepJogEndtoFace_Output", "index": "1", "active": "true"}]}, {"preview": "ModlAeroUI_Step/AeroStepJogCutout.png", "title": "Aero_Step_Jog_Cutout", "description": "A Step Jog Cutout feature using type Jog and an edge reference type.", "index": "2", "active": "true", "reflect": "UGS::ModlAeroUI::Step::0::Visual Assistant - Jog Cutout", "models": [{"label": "Input", "path": "ModlAeroUI_Step/AeroStepJogCutout_Input", "index": "0", "active": ""}, {"label": "Output", "path": "ModlAeroUI_Step/AeroStepJogCutout_Output", "index": "1", "active": "true"}, {"label": "Section", "path": "ModlAeroUI_Step/AeroStepJogCutout_Section", "index": "2", "active": ""}]}, {"preview": "ModlAeroUI_Step/AeroStepThickCorner.png", "title": "Aero_Step_Jog_Cutout", "description": "A Step feature using type Thin from the end using reference type Edge", "index": "3", "active": "", "reflect": "UGS::ModlAeroUI::Step::0::Visual Assistant - Thick Corner", "models": [{"label": "Input", "path": "ModlAeroUI_Step/AeroStepThickCorner_Input", "index": "0", "active": ""}, {"label": "Output", "path": "ModlAeroUI_Step/AeroStepThickCorner_Output", "index": "1", "active": "true"}]}], "config": {"reverseScroll": "false"}}
	
	this.OnContentReceived(parsedEventData);
};