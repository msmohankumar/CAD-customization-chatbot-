﻿/*HEAD UGS_MessageService js */
/*==================================================================================================

        Copyright (c) 2018 Siemens Product Lifecycle Management Software Inc.
                     Unpublished - All rights reserved

====================================================================================================
File description:


====================================================================================================
Date         Name                    Description of Change
20-Mar-2018  Satyajit Majumder       Written
$HISTORY$
==================================================================================================*/

'use strict';	

UGS.MessageService = function (FQN, SvcVersion, OutgoingFQN, OutgoingSvcVersion) 
{
	UGS.debugMessage("New MessageService : " + FQN + " : " + SvcVersion + " : " + OutgoingFQN + " : " + OutgoingSvcVersion);

	// The fully qualified name and version number strings
	// of this service.
	// Override service instance.
	this.FQN                = FQN;
	this.SvcVersion         = SvcVersion;
	
	this.OutgoingFQN        = OutgoingFQN;
	this.OutgoingSvcVersion = OutgoingSvcVersion;
	
};

UGS.MessageService.prototype.HandleEventCall = function(dataContract) 
{ 
	// This function is called whenever the host application
	// calls InvokeWebEvent. It is not expected to return any
	// information back to the host, but any exception that is
	// thrown by this function will be "re-thrown" in the
	// host environment (sort of).
	try{
	
		UGS.debugMessage("HandleEventCall " + JSON.stringify(dataContract));
		
		var parsedEventData = JSON.parse(dataContract);
		this.ProcessEvent(parsedEventData);
	}
	catch(err)
	{
		UGS.debugMessage("HandleEventCall " + JSON.parse);
	}
};
		
UGS.MessageService.prototype.ProcessEvent = function(parsedEventData) 
{ 
	// Override processing in custom service
};

UGS.MessageService.prototype.PerformOperation = function(inputMessage) 
{
    try
	{
		if (globalhostedInfo === null || globalhostedInfo === undefined)
			return;
		
		// Identify the service on the host that we wish to invoke.
		// This is done with a "service descriptor", which is simply
		// an object which has two string fields:
		//      FQN (fully qualified name): the name of the service
		//      SvcVersion: The version number
		var liveHelpStringServiceDesc = { FQN: this.OutgoingFQN, SvcVersion: this.OutgoingSvcVersion };
				
		UGS.debugMessage('Sending Message to NX : '+inputMessage);
		
		globalhostedInfo.CallHostEvent(liveHelpStringServiceDesc, inputMessage);
		
	}
	catch(err)
	{ 
	    UGS.debugMessage("Error in performOperation " + err)
		return;
	}
};