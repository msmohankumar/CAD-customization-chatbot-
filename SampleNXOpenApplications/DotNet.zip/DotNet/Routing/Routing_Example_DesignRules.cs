/*==================================================================================================
               Copyright 2017 Siemens Product Lifecycle Management Software Inc.
====================================================================================================

    NOTE:  NX Development provides programming examples for illustration only.
    NX Development assumes you are familiar with the programming language
    demonstrated in these examples, and the tools used to create and debug NX/Open
    programs. GTAC support professionals can help explain the functionality of
    a particular procedure, but neither GTAC nor NX Development will modify
    these examples to provide added functionality or construction procedures.

File description:

    A C# class that implements example Routing Design Rules.


==================================================================================================*/
using NXOpen;
using NXOpen.UF;
using NXOpen.Assemblies;
using NXOpen.Preferences;
using NXOpen.Routing;
using NXOpen.Routing.Electrical;
using System.Collections.Generic;

namespace Routing
{
    public class DesignRules
    {
        // Static class members
        static Session theSession = null;
        static CustomManager customManager = null;
        static int createPathRuleId = 0;
        static int subdivideSegmentRuleId = 0;
        static int modularConnectorRuleId = 0;
        static string createPathName = "Create Path";
        static string subdivideSegmentName = "Subdivide Segment";
        static string modularConnectorName = "Modular Connector";

        //------------------------------------------------------------------------------------------
        // Called when NX starts up to register the Design Rules.
        public static int Startup()
        {
            if (theSession == null)
                theSession = Session.GetSession();

            if (customManager == null)
                customManager = theSession.RouteCustomManager;

            RegisterDesignRules();

            theSession.LicenseManager.ReleaseAll( null );

            return 0;
        }

        //------------------------------------------------------------------------------------------
        // Called from File->Execute->NX Open. Useful for testing.
        public static void Main()
        {
            if (theSession == null)
                theSession = Session.GetSession();

            if (customManager == null)
                customManager = theSession.RouteCustomManager;

            RegisterDesignRules();
        }

        //------------------------------------------------------------------------------------------
        // Called by both Main and Startup to register the Design Rules.
        private static void RegisterDesignRules()
        {
            string createPathDescription = "The Create Path design rule makes sure each segment on the path is not too long.";
            string subdivideSegmentDescription = "The Subdivide Segment design rule makes sure each new segment is not too short.";
            string modularConnectorDescription = "The Modular Connector design rule makes sure modular connectors are plugged into the correct position on the parent shell.";

            createPathRuleId = customManager.AddDesignRule( CustomManager.DesignRuleReason.CreatePath, createPathName, createPathDescription, CreatePathDesignRule );
            subdivideSegmentRuleId = customManager.AddDesignRule( CustomManager.DesignRuleReason.SubdivideSegment, subdivideSegmentName, subdivideSegmentDescription, SubdivideSegmentDesignRule );
            modularConnectorRuleId = customManager.AddDesignRule( CustomManager.DesignRuleReason.Interactive, modularConnectorName, modularConnectorDescription, ModularConnectorDesignRule );
        }

        //------------------------------------------------------------------------------------------
        static void CreatePathDesignRule
        (
            CustomManager.DesignRuleReason reason,
            NXObject[] nxObjects
        )
        {
            double maximumLength = 1000.0;

            if (reason == CustomManager.DesignRuleReason.Interactive)
            {
                // For interactive checks, check all the segments in the work part.
                SegmentManager segmentManager = theSession.Parts.Work.SegmentManager;
                ISegmentCollection segmentCollection = segmentManager.Segments;

                foreach (ISegment segment in segmentCollection)
                    checkForLongSegments( createPathName, maximumLength, segment );

                return;
            }

            // Otherwise, check the segments in the given list of objects.
            foreach (NXObject nxObject in nxObjects)
            {
                if (nxObject.GetType() == typeof( SplineSegment ))
                    checkForLongSegments( createPathName, maximumLength, (ISegment)nxObject );
            }
        }

        //------------------------------------------------------------------------------------------
        // Checks the length of the given segment against the maximum allowed length.
        //
        // Creates a violation for the given reason if the segment is too long.
        //
        // \param[in]
        //      maximumLength
        //          The longest length allowed.
        //
        // \param[in]
        //      segment
        //          The segment to check.
        static void checkForLongSegments
        (
            string designRuleName,
            double maximumLength,
            ISegment segment
        )
        {
            if (segment.Length < maximumLength)
                return;

            List<NXObject> objects = new List<NXObject>();
            objects.Add( (Curve)segment );

            // NOTE: The design rule name given on the violation must match the name given to the
            //       rule when registering.
            customManager.CreateViolationForReason( designRuleName,
                                                   CustomManager.DesignRuleReason.CreatePath,
                                                   "This path is too long.",
                                                   "Long paths need to be broken up and supported by clamps.",
                                                   objects.ToArray() );
        }

        //------------------------------------------------------------------------------------------
        static void SubdivideSegmentDesignRule
        (
            CustomManager.DesignRuleReason reason,
            NXObject[] nxObjects
        )
        {
            RoutingUserPreferences userPreferences = theSession.Preferences.RoutingApplicationView.RoutingUserPreferences;

            double minimumLength = 0.0;
            if (!userPreferences.GetDoublePreference( "ROUTE_ELEC_MIN_STRAIGHT_LENGTH_COEFF", out minimumLength ))
                minimumLength = 10.0;

            if (reason == CustomManager.DesignRuleReason.Interactive)
            {
                // For interactive checks, check all the segments in the work part.
                SegmentManager segmentManager = theSession.Parts.Work.SegmentManager;
                ISegmentCollection segmentCollection = segmentManager.Segments;

                foreach (ISegment segment in segmentCollection)
                    checkForShortSegments( subdivideSegmentName, minimumLength, segment );

                return;
            }

            // Otherwise, check the segments in the given list of objects.
            foreach (NXObject nxObject in nxObjects)
            {
                if (nxObject.GetType() == typeof( SplineSegment ))
                    checkForShortSegments( subdivideSegmentName, minimumLength, (ISegment)nxObject );
            }
        }

        //------------------------------------------------------------------------------------------
        // Safely gets the value of a string characteristic if it exists on the route object.
        //
        // \param[in]
        //      routeObject 
        //          The object from which to get the characteristic.
        //
        // \param[in]
        //      characteristicName 
        //          The name of the characteristic to get.
        //
        // \return
        //      The string value of the characteristic. Will be null if the characteristic does not exist
        //      or is not a string.
        private static string getCharacteristicFromObject
        (
            RouteObject routeObject,
            string characteristicName
        )
        {
            CharacteristicList characteristics = routeObject.GetCharacteristics();
            CharacteristicList.CharacteristicInformation[] characteristicsInfo = characteristics.GetCharacteristicTitlesByType( NXObject.AttributeType.Any );

            foreach (CharacteristicList.CharacteristicInformation characteristicInfo in characteristicsInfo)
            {
                if (characteristicName == characteristicInfo.Name &&
                     characteristicInfo.Type == NXObject.AttributeType.String)
                {
                    return characteristics.GetStringCharacteristic( characteristicName );
                }
            }

            return null;
        }

        //--------------------------------------------------------------------------------------------------
        // Returns the names of the ports to which the connector is connected through a port connection.
        //
        // \param[in]
        //      connector 
        //          The connector to check.
        //
        // \return
        //      The names of the ports to which this connector is connected. Will be null if the connector
        //      is not assigned to a component or if the component's ports are not connected to any other
        //      ports.
        static string[] getConnectedPortNames
        (
            ConnectorDevice connector
        )
        {
            if (!connector.IsAssigned())
                return null;

            Component assignedComponent = (Component)connector.NxEquivalent;
            if (assignedComponent == null)
                return null;

            RouteManager routeManager = theSession.Parts.Work.RouteManager;
            Port[] assignedComponentPorts = routeManager.Ports.GetComponentPorts( assignedComponent );
            if (assignedComponentPorts == null)
                return null;

            List<string> connectedPortNames = new List<string>();

            PortConnectionCollection portConnections = routeManager.PortConnections;
            foreach (Port assignedComponentPort in assignedComponentPorts)
            {
                PortConnection portConnection = portConnections.GetConnectionFromPort( assignedComponentPort );
                if (portConnection == null)
                    continue;

                Port port1 = null;
                Port port2 = null;
                portConnection.GetPorts( out port1, out port2 );

                // We know the port on the connector, so get the name from the other port in the connection.
                connectedPortNames.Add( assignedComponentPort != port1 ? port1.Name : port2.Name );
            }

            return connectedPortNames.ToArray();
        }

        //------------------------------------------------------------------------------------------
        static void ModularConnectorDesignRule
        (
            CustomManager.DesignRuleReason reason,
            NXObject[] nxObjects
        )
        {
            if (reason != CustomManager.DesignRuleReason.Interactive)
                return;

            RouteManager routeManager = theSession.Parts.Work.RouteManager;
            ConnectorDeviceCollection connectors = routeManager.ConnectorDevices;

            // For every Connector Device that is assigned and has a modular connector parent,
            // check that the assigned component is at the correct position (i.e. the correct port).
            foreach (ConnectorDevice connector in connectors)
            {
                if (!connector.IsAssigned())
                    continue;

                string parentConnectorName = getCharacteristicFromObject( connector, UFConstants.UF_RLIST_PARENT_ID_NAME );
                if (parentConnectorName == null)
                    continue;

                string parentPortName = getCharacteristicFromObject( connector, UFConstants.UF_RLIST_PARENT_POSITION_NAME );
                if (parentPortName == null)
                    continue;

                bool connectedCorrectly = false;
                string portNamesForMessage = null;
                string[] connectedPortNames = getConnectedPortNames( connector );

                foreach (string connectedPortName in connectedPortNames)
                {
                    portNamesForMessage += connectedPortName + ", ";

                    if (connectedPortName == parentPortName)
                    {
                        connectedCorrectly = true;
                        break;
                    }
                }

                if (!connectedCorrectly)
                {
                    List<NXObject> objects = new List<NXObject>();
                    objects.Add( connector.NxEquivalent );

                    string message = "Connector " + connector.Name;
                    message += " is connected to port(s) " + portNamesForMessage;
                    message += "but should be connected to port " + parentPortName;
                    message += " on connector " + parentConnectorName + ".";

                    // NOTE: The design rule name given on the violation must match the name given to the
                    //       rule when registering.
                    customManager.CreateViolationForReason( modularConnectorName, reason,
                                                            "Component connected to wrong port.",
                                                            message, objects.ToArray() );
                }
            }
        }

        //------------------------------------------------------------------------------------------
        // Checks the length of the given segment against the minimum allowed length.
        //
        // Creates a violation for the given reason if the segment is too short.
        //
        // \param[in]
        //      minimumLength
        //          The shortest length allowed.
        //
        // \param[in]
        //      segment
        //          The segment to check.
        static void checkForShortSegments
        (
            string designRuleName,
            double minimumLength,
            ISegment segment
        )
        {
            if (segment.Length > minimumLength)
                return;

            List<NXObject> objects = new List<NXObject>();
            objects.Add( (Curve)segment );

            // NOTE: The design rule name given on the violation must match the name given to the
            //       rule when registering.
            customManager.CreateViolationForReason( designRuleName,
                                                   CustomManager.DesignRuleReason.SubdivideSegment,
                                                   "This segment is too short.",
                                                   "Short segments violate our design standards.",
                                                   objects.ToArray() );
        }

        //------------------------------------------------------------------------------------------
        // Tells NX when to unload your application.
        // For Routing callbacks, plugins, and Design Rules, this MUST return AtTermination.
        public static int GetUnloadOption( string arg )
        {
            return System.Convert.ToInt32( Session.LibraryUnloadOption.AtTermination );
        }
    }
}
